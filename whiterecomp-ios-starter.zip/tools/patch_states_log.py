#!/usr/bin/env python3
"""patch_states_log.py -- log each distinct alpha-related render-state
combination seen at draw time in the extracted vk_d3d9.c.

Usage: patch_states_log.py <path-to-vk_d3d9.c>

The A2C markers (patch_a2c_log.py) never fired: at no draw was the game's
alpha-test func "always" while an A2M1/ATOC state was set. This logger sits
at the same spot and reports every NEW combination of

    alpha test enable / func / ref, A2M1 set, ATOC set, render-target samples

so one run shows how the game actually draws its alpha-tested material
(hair, eyelashes): its own test with which threshold, a vendor state with
the test also on, or no test at all. At most 24 lines per run.

Idempotent; fails loudly if the anchor is not found.
"""
import sys

ANCHOR = '\t\t\t\tstatic int at_all = -1; /* (XRC_VK_ALPHA_ALWAYS=1, tools builds: every draw with the test, as before -- to compare) */'

LOGGER = (
    "\t\t\t\t{ static unsigned combos[24]; static int ncombos;\n"
    "\t\t\t\t  unsigned sig = (dev.rs[15] ? 1u : 0u) | ((unsigned)(af & 15) << 1) | ((unsigned)(dev.rs[24] & 0xff) << 5) |\n"
    "\t\t\t\t      (dev.rs[154] == FOURCC('A', '2', 'M', '1') ? 1u << 13 : 0u) | (dev.rs[181] == FOURCC('A', 'T', 'O', 'C') ? 1u << 14 : 0u) | ((unsigned)(key.ms & 7) << 15);\n"
    "\t\t\t\t  int ci, cfound = 0; for (ci = 0; ci < ncombos; ci++) if (combos[ci] == sig) { cfound = 1; break; }\n"
    "\t\t\t\t  if (!cfound && ncombos < 24) { combos[ncombos++] = sig;\n"
    "\t\t\t\t      fprintf(stderr, \"xrc-ios: alpha state: test %u func %d ref %u a2m1 %u atoc %u rt samples %u\\n\",\n"
    "\t\t\t\t              dev.rs[15] ? 1 : 0, af, dev.rs[24] & 0xff,\n"
    "\t\t\t\t              dev.rs[154] == FOURCC('A', '2', 'M', '1') ? 1 : 0, dev.rs[181] == FOURCC('A', 'T', 'O', 'C') ? 1 : 0, (unsigned)key.ms); } }\n"
)


def main() -> int:
    path = sys.argv[1]
    with open(path, "r", encoding="utf-8", errors="replace") as f:
        text = f.read()
    if "xrc-ios: alpha state:" in text:
        print("patch_states_log: already applied")
        return 0
    if ANCHOR not in text:
        print("patch_states_log: anchor not found", file=sys.stderr)
        return 1
    text = text.replace(ANCHOR, LOGGER + ANCHOR, 1)
    with open(path, "w", encoding="utf-8") as f:
        f.write(text)
    print("patch_states_log: logger inserted")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
