#!/usr/bin/env python3
"""Extract the FFBUNDL2 source bundle embedded in a WhiteRecomp launcher binary.

Format (from the public launcher source, launcher_src/bundle.odin in
ps4star/WhiteRecomp):
  header : "FFBUNDL2" + u32le block_count + u32le file_count
  blocks : block_count x { u64le size, u64le packed, u64le offset }   (offset is
           relative to the start of the bundle)
  entries: file_count x { u16le path_len, path bytes, u32le flags,
           u32le block, u64le offset_in_block, u64le size }
  block data: one LZMA-Alone stream per block (files of one folder, <=32 MB
           uncompressed), located at bundle_start + block.offset

The macOS launcher is a fat (universal) binary, so the bundle appears twice
(once per architecture slice); both copies are identical and only the first
is used.

Usage:
  python3 extract_bundle.py <launcher-binary> <output-dir> [--list]
"""
import lzma
import os
import struct
import sys


def find_bundle(data: bytes) -> int:
    at = data.find(b"FFBUNDL2")
    if at < 0:
        raise SystemExit("FFBUNDL2 magic not found - not a WhiteRecomp launcher?")
    return at


def parse(data: bytes, start: int):
    nb, nf = struct.unpack_from("<II", data, start + 8)
    o = start + 16
    blocks = []
    for _ in range(nb):
        size, packed, off = struct.unpack_from("<QQQ", data, o)
        o += 24
        blocks.append((size, packed, off))
    entries = []
    for _ in range(nf):
        (pl,) = struct.unpack_from("<H", data, o)
        o += 2
        path = data[o : o + pl].decode("utf-8")
        o += pl
        flags, block, eoff, esize = struct.unpack_from("<IIQQ", data, o)
        o += 24
        entries.append((path, flags, block, eoff, esize))
    return blocks, entries


def main() -> int:
    if len(sys.argv) < 3:
        print(__doc__)
        return 2
    binary, outdir = sys.argv[1], sys.argv[2]
    list_only = "--list" in sys.argv
    data = open(binary, "rb").read()
    start = find_bundle(data)
    blocks, entries = parse(data, start)
    total = sum(e[4] for e in entries)
    print(f"bundle at offset {start}: {len(blocks)} blocks, {len(entries)} files, "
          f"{total / 1e6:.1f} MB uncompressed")
    if list_only:
        for path, _f, _b, _o, size in entries:
            print(f"{size:>10}  {path}")
        return 0

    # Decompress each block once, then slice out its files.
    block_data = {}
    for bi, (size, packed, off) in enumerate(blocks):
        raw = data[start + off : start + off + packed]
        dec = lzma.LZMADecompressor(format=lzma.FORMAT_ALONE)
        out = dec.decompress(raw, max_length=size)
        if len(out) != size:
            raise SystemExit(f"block {bi}: decompressed {len(out)} bytes, expected {size}")
        block_data[bi] = out

    written = 0
    for path, _flags, block, eoff, esize in entries:
        # Never let a bundle path escape the output directory.
        dest = os.path.normpath(os.path.join(outdir, path))
        if not dest.startswith(os.path.normpath(outdir) + os.sep):
            print(f"SKIP unsafe path: {path}")
            continue
        os.makedirs(os.path.dirname(dest), exist_ok=True)
        with open(dest, "wb") as fh:
            fh.write(block_data[block][eoff : eoff + esize])
        written += 1
    print(f"extracted {written} files to {outdir}")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
