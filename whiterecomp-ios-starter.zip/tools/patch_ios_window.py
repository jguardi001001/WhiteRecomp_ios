#!/usr/bin/env python3
"""Keep the iOS build on vk_d3d9.c's SDL window path in WhiteRecomp v0.0.12.

Upstream v0.0.12 gives macOS its own window: an `#elif defined(__APPLE__)`
branch that makes an AppKit NSWindow through xrc_cocoa.c (VK_EXT_metal_surface)
instead of an SDL window. iOS is `__APPLE__` too, so an unpatched iOS build
would take that branch -- and AppKit does not exist on iOS. Our port's whole
window design (SDL UIKit window, adopted onto the app's UIScene by
ios_main.m, native-scale Metal layer) needs the SDL branch, which is still
there as the fallback (Linux uses it).

So: the two conditions that select Cocoa get `&& !defined(XRC_IOS)`, and
build_ios.sh compiles the runtime with -DXRC_IOS and skips xrc_cocoa.c.
plat_unusable's Apple branch (a Cocoa alert + exit) is steered the same
way; on iOS it stays the no-op it is on Linux.

Third edit, same family: v0.0.12's SDL plat_hidden() refuses to present
when SDL_GetWindowFlags says HIDDEN (0x8) or MINIMIZED (0x40) -- a
Wayland safeguard. On iOS the window is adopted onto the scene by
ios_main.m at the UIKit level, which SDL's flag bookkeeping never hears
about (SDL's own app delegate is not running), so the flags latch
"hidden" and presenting stops forever: black screen with the game
running. On iOS plat_hidden() returns 0; ios_main.m additionally tells
SDL to show/restore the window at adoption time.

Idempotent; fails loudly if an anchor is not found.

Usage: patch_ios_window.py <path-to-vk_d3d9.c>
"""
import sys

EDITS = [
    (
        "#elif defined(__APPLE__) || defined(XRC_COCOA_EMU)",
        "#elif (defined(__APPLE__) && !defined(XRC_IOS)) || defined(XRC_COCOA_EMU)",
    ),
    (
        "#if defined(__APPLE__) || defined(XRC_COCOA_EMU)",
        "#if (defined(__APPLE__) && !defined(XRC_IOS)) || defined(XRC_COCOA_EMU)",
    ),
    (
        "static int plat_hidden(void) {\n"
        "\treturn __atomic_load_n(&win_shown, __ATOMIC_ACQUIRE) && window && SDL_GetWindowFlags_ && (SDL_GetWindowFlags_(window) & (0x40u | 0x8u));\n"
        "}",
        "static int plat_hidden(void) {\n"
        "#ifdef XRC_IOS\n"
        "\treturn 0; /* (iOS: visibility is managed by ios_main.m's scene adoption; SDL's window flags never learn of it) */\n"
        "#else\n"
        "\treturn __atomic_load_n(&win_shown, __ATOMIC_ACQUIRE) && window && SDL_GetWindowFlags_ && (SDL_GetWindowFlags_(window) & (0x40u | 0x8u));\n"
        "#endif\n"
        "}",
    ),
]


def main() -> int:
    path = sys.argv[1]
    with open(path, "r", encoding="utf-8", errors="replace") as f:
        text = f.read()
    changed = False
    for anchor, replacement in EDITS:
        if replacement in text:
            continue  # already in
        if anchor not in text:
            print(f"patch_ios_window: anchor not found: {anchor!r}", file=sys.stderr)
            return 1
        text = text.replace(anchor, replacement, 1)
        changed = True
    if changed:
        with open(path, "w", encoding="utf-8") as f:
            f.write(text)
        print("patch_ios_window: Cocoa branch steered away from iOS (SDL window kept)")
    else:
        print("patch_ios_window: already applied")
    return 0


if __name__ == "__main__":
    sys.exit(main())
