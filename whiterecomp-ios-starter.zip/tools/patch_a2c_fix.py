#!/usr/bin/env python3
"""Backport the WhiteRecomp v0.0.12 alpha-to-coverage fix into the v0.0.9
runtime's vk_d3d9.c.

The bug (fixed upstream in v0.0.12, from its release notes): "The game draws
[hair and eyelashes] with alpha-to-coverage, which it turns on through the
GPU vendors' D3D9 extensions. These were handled the wrong way round, so
hair and eyelashes got a hard, jagged cutout instead of soft edges."

Concretely: ATI's 'A2M1' (render state 154, POINTSIZE) engages on its own,
but NVIDIA's 'ATOC' (render state 181, ADAPTIVETESS_Y) engages only WITH
the game's alpha test enabled -- and then replaces the test. The v0.0.9
renderer required the alpha test to be OFF (af == 8) for both, so for this
game -- which is told it has an NVIDIA GPU and sets ATOC with its alpha
test on -- coverage never engaged: the test was kept and the edges stayed
hard binary cutouts, at any MSAA level.

Two spots, both mirroring v0.0.12's vk_d3d9.c:
  1. the draw-path decision (which also feeds key.at via af),
  2. the push constants (coverage replaces the shader alpha test).

Works on a pristine v0.0.9 file and on one already carrying the
patch_a2c_log.py / patch_states_log.py diagnostics (their lines are left
in place; they still compile against the same variables). Idempotent;
fails loudly if an anchor is not found.

Usage: patch_a2c_fix.py <path-to-vk_d3d9.c>
"""
import sys

SPOT1_OLD = (
    "\t\t\t\tkey.ms = (u8)rt_samples();\n"
    "\t\t\t\tif (af == 8 && (dev.rs[154] == FOURCC('A', '2', 'M', '1') || dev.rs[181] == FOURCC('A', 'T', 'O', 'C'))) {\n"
    "\t\t\t\t\tif (key.ms > 1) key.a2c = 1; else af = 7; /* (alpha to coverage: real when multisampled, else a test) */\n"
    "\t\t\t\t}"
)
SPOT1_NEW = (
    "\t\t\t\tint amd = dev.rs[154] == FOURCC('A', '2', 'M', '1'), nv = dev.rs[181] == FOURCC('A', 'T', 'O', 'C');\n"
    "\t\t\t\tkey.ms = (u8)rt_samples();\n"
    "\t\t\t\t/* alpha to coverage, as the drivers (and DXVK) do the two hacks: ATI's POINTSIZE 'A2M1' on its own, NVIDIA's\n"
    "\t\t\t\t * ADAPTIVETESS_Y 'ATOC' only with the alpha test enabled -- and then in place of the test. The game (which is\n"
    "\t\t\t\t * told it has an NVIDIA GPU) sets both for its hair and eyelashes, with the alpha test on: the old condition\n"
    "\t\t\t\t * here required the test OFF, so coverage never engaged and hair was a hard cutout. (v0.0.12 fix, backported) */\n"
    "\t\t\t\tif (key.ms > 1 && (amd || (nv && af != 8))) { key.a2c = 1; af = 8; }\n"
    "\t\t\t\telse if (key.ms <= 1 && af == 8 && (amd || nv)) af = 7;"
)

_PC_TAIL = "(dev.rs[154] == FOURCC('A', '2', 'M', '1') || dev.rs[181] == FOURCC('A', 'T', 'O', 'C'))"
SPOT2_OLD_VARIANTS = [
    # pristine v0.0.9
    "\t\t\tif (pc.afunc == 8 && !key.a2c && " + _PC_TAIL + ") { pc.afunc = 7; pc.aref = 0.5f; }",
    # with the patch_a2c_log.py fallback marker inside
    "\t\t\tif (pc.afunc == 8 && !key.a2c && " + _PC_TAIL + ") { static int fb_said; "
    "if (!fb_said) { fb_said = 1; fprintf(stderr, \"xrc-ios: A2C fallback alpha test 0.5 for a draw\\n\"); } "
    "pc.afunc = 7; pc.aref = 0.5f; }",
]
SPOT2_NEW = (
    "\t\t\tif (key.a2c) pc.afunc = 8; /* (the coverage in place of the test) */\n"
    "\t\t\telse if (pc.afunc == 8 && " + _PC_TAIL + ") { pc.afunc = 7; pc.aref = 0.5f; }"
)


def main() -> int:
    path = sys.argv[1]
    with open(path, "r", encoding="utf-8", errors="replace") as f:
        text = f.read()
    if "(nv && af != 8)" in text:
        print("patch_a2c_fix: already applied")
        return 0
    if SPOT1_OLD not in text:
        print("patch_a2c_fix: anchor not found (draw-path A2C block)", file=sys.stderr)
        return 1
    text = text.replace(SPOT1_OLD, SPOT1_NEW, 1)
    for old in SPOT2_OLD_VARIANTS:
        if old in text:
            text = text.replace(old, SPOT2_NEW, 1)
            break
    else:
        print("patch_a2c_fix: anchor not found (push-constant A2C line)", file=sys.stderr)
        return 1
    with open(path, "w", encoding="utf-8") as f:
        f.write(text)
    print("patch_a2c_fix: v0.0.12 alpha-to-coverage fix applied")
    return 0


if __name__ == "__main__":
    sys.exit(main())
