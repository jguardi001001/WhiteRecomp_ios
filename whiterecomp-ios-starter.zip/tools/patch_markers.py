#!/usr/bin/env python3
"""patch_markers.py -- insert stage markers into the extracted xrc_rt.c.

Usage: patch_markers.py <path-to-xrc_rt.c>

The game's main() already makes stderr unbuffered as its first act, so
fprintf markers placed after that line survive even a hard crash -- unlike
the iOS shim's stdio prints, which can die in a buffer. These markers split
startup into stages so one look at ff13.log shows exactly how far it got:

    (nothing)            SDL_main was never called
    xrc-ios: SDL_main entered
    xrc-ios: loading exe <path>
    xrc: ... loaded ...  (the runtime's own line, already there)

Idempotent: running it again changes nothing. Fails loudly if an anchor
line is not found (upstream changed the file -- better a build error than
a silently unmarked binary).
"""
import sys

MARK = "xrc-ios:"

INSERTIONS = [
    (
        'setvbuf(stderr, 0, _IONBF, 0);',
        '\tfprintf(stderr, "xrc-ios: SDL_main entered\\n");',
    ),
    (
        'if (!load_exe(exe)) return 2;',
        '\tfprintf(stderr, "xrc-ios: loading exe %s\\n", exe);',
    ),
    (
        "xrc_argv = argv + 2; /* the game's own arguments follow the exe path */",
        '\t{ int k; fprintf(stderr, "xrc-ios: runtime game argv (%d):", xrc_argc); '
        'for (k = 0; k < xrc_argc; k++) fprintf(stderr, " %s", xrc_argv[k]); '
        'fprintf(stderr, "\\n"); }',
    ),
]


def main() -> int:
    path = sys.argv[1]
    with open(path, "r", encoding="utf-8", errors="replace") as f:
        text = f.read()
    changed = False
    for anchor, line in INSERTIONS:
        if line in text:
            continue  # this marker is already in (per-marker idempotency)
        if anchor not in text:
            print(f"patch_markers: anchor not found: {anchor!r}", file=sys.stderr)
            return 1
        if anchor.startswith("if "):
            text = text.replace(anchor, line + "\n\t" + anchor, 1)
        else:
            text = text.replace(anchor, anchor + "\n" + line, 1)
        changed = True
    if changed:
        with open(path, "w", encoding="utf-8") as f:
            f.write(text)
        print("patch_markers: markers inserted")
    else:
        print("patch_markers: already applied")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
