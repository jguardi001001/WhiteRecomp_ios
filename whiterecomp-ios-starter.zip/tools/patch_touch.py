#!/usr/bin/env python3
"""patch_touch.py -- open the Android touch controls to the iOS build.

Usage: patch_touch.py <path-to-vk_d3d9.c> <path-to-xrc_android.h>

The touch system already exists in the bundle, gated on __ANDROID__:
the layout/state API in xrc_android.h, the drawing in vk_d3d9.c
(touch_overlay, called from be_present), the state machine and pad in
xrc_android.c. iOS provides its own state machine + pad in
ios/src/xrc_ios_touch.c (SDL finger events in, an SDL virtual game
controller out -- hle_dinput.c needs no changes, its SDL backend
enumerates the virtual pad like a real one). This patch only opens
the shared pieces to a build that defines XRC_TOUCH_PAD, and teaches
vk_d3d9.c's SDL event pump about fingers:

  xrc_android.h   the API guard: __ANDROID__ -> also XRC_TOUCH_PAD
  vk_d3d9.c       the overlay's guard and its call site, the same way
                  pump_events: finger events forwarded to the touch
                  controls; a real controller's events hide them;
                  mouse events SDL synthesized from touches (their
                  `which` is SDL_TOUCH_MOUSEID) are not ALSO fed to
                  the mouse while the touch controls are enabled

Idempotent: running it again changes nothing. Fails loudly if an
anchor is not found (upstream changed the file -- better a build
error than a silently touch-less binary).
"""
import sys

TOUCH_GUARD = "#if defined(__ANDROID__) || defined(XRC_TOUCH_PAD)"

VK_EDITS = [
    # the shared API + the iOS touch entry points, before the SDL
    # branch's pump_events
    (
        "/* the window's events: closing it ends the game; keyboard and mouse go to the DirectInput HLE (SDL2 event layouts) */",
        "#ifdef XRC_TOUCH_PAD\n"
        "#include \"xrc_android.h\" /* the touch controls' shared API (the iOS pad itself: ios/src/xrc_ios_touch.c) */\n"
        "extern int xrc_ios_touch_finger(const void *ev, int winw, int winh, int vx0, int vy0, int vw, int vh);\n"
        "extern void xrc_ios_touch_hide(int instance_id);\n"
        "extern int xrc_ios_touch_enabled(void);\n"
        "#endif\n",
        "before",
    ),
    # a touch SDL turned into a mouse motion is not also a mouse motion
    (
        "\t\tcase 0x400: /* SDL_MOUSEMOTION: x y at 20, xrel yrel at 28 (window points: scaled to the game's pixels) */\n"
        "\t\t\txrc_input_mouse(ev.i[7], ev.i[8], 0);",
        "\t\tcase 0x400: /* SDL_MOUSEMOTION: x y at 20, xrel yrel at 28 (window points: scaled to the game's pixels) */\n"
        "#ifdef XRC_TOUCH_PAD\n"
        "\t\t\tif (ev.i[3] == -2 && xrc_ios_touch_enabled()) break; /* `which` is SDL_TOUCH_MOUSEID: a touch, and the touch controls have it */\n"
        "#endif\n"
        "\t\t\txrc_input_mouse(ev.i[7], ev.i[8], 0);",
        "replace",
    ),
    # same for a synthesized mouse button
    (
        "\t\tcase 0x401: case 0x402: /* SDL_MOUSEBUTTONDOWN / UP: the button at 16 */\n"
        "\t\t\txrc_input_button(ev.b[16], ev.type == 0x401);",
        "\t\tcase 0x401: case 0x402: /* SDL_MOUSEBUTTONDOWN / UP: the button at 16 */\n"
        "#ifdef XRC_TOUCH_PAD\n"
        "\t\t\tif (ev.i[3] == -2 && xrc_ios_touch_enabled()) break; /* SDL_TOUCH_MOUSEID: a touch, and the touch controls have it */\n"
        "#endif\n"
        "\t\t\txrc_input_button(ev.b[16], ev.type == 0x401);",
        "replace",
    ),
    # finger events to the touch controls; a real controller hides them
    (
        "\t\t\txrc_user32_mouse_wheel(ev.i[5] * 120);\n"
        "\t\t\tbreak;",
        "\t\t\txrc_user32_mouse_wheel(ev.i[5] * 120);\n"
        "\t\t\tbreak;\n"
        "#ifdef XRC_TOUCH_PAD\n"
        "\t\tcase 0x700: case 0x701: case 0x702: { /* SDL_FINGERDOWN / UP / MOTION: the touch controls (ww / wh here are the picture's part of the window) */\n"
        "\t\t\tint pw = 0, ph = 0;\n"
        "\t\t\tif (SDL_GetWindowSize_) SDL_GetWindowSize_(window, &pw, &ph);\n"
        "\t\t\txrc_ios_touch_finger(&ev, pw, ph, vx0, vy0, ww, wh);\n"
        "\t\t\tbreak; }\n"
        "\t\tcase 0x650: case 0x651: /* SDL_CONTROLLERAXISMOTION / BUTTONDOWN: a real controller in use hides the touch controls */\n"
        "\t\t\txrc_ios_touch_hide(ev.i[2]);\n"
        "\t\t\tbreak;\n"
        "#endif",
        "replace",
    ),
    # the overlay itself
    (
        "#ifdef __ANDROID__\n"
        "/* ============================================================================================ touch controls",
        TOUCH_GUARD + "\n"
        "/* ============================================================================================ touch controls",
        "replace",
    ),
    # and its call in be_present
    (
        "#ifdef __ANDROID__\n"
        "\ttouch_overlay(bb);\n"
        "#endif",
        TOUCH_GUARD + "\n"
        "\ttouch_overlay(bb);\n"
        "#endif",
        "replace",
    ),
]

HEADER_EDITS = [
    (
        "#ifdef __ANDROID__",
        TOUCH_GUARD,
        "replace",
    ),
]


def apply(path, edits, sentinel):
    with open(path, "r", encoding="utf-8", errors="replace") as f:
        text = f.read()
    if sentinel in text:
        print(f"patch_touch: {path}: already applied")
        return 0
    for anchor, replacement, mode in edits:
        if text.count(anchor) != 1:
            print(f"patch_touch: anchor not unique/found in {path}: {anchor[:70]!r} (x{text.count(anchor)})",
                  file=sys.stderr)
            return 1
        if mode == "before":
            text = text.replace(anchor, replacement + anchor, 1)
        else:
            text = text.replace(anchor, replacement, 1)
    with open(path, "w", encoding="utf-8") as f:
        f.write(text)
    print(f"patch_touch: {path}: touch opened to XRC_TOUCH_PAD")
    return 0


def main() -> int:
    vk_path, header_path = sys.argv[1], sys.argv[2]
    rc = apply(vk_path, VK_EDITS, "xrc_ios_touch_finger")
    if rc:
        return rc
    return apply(header_path, HEADER_EDITS, "defined(XRC_TOUCH_PAD)")


if __name__ == "__main__":
    raise SystemExit(main())
