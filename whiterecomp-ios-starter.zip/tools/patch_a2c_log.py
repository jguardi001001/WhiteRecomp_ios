#!/usr/bin/env python3
"""patch_a2c_log.py -- one-time diagnostic logs for the alpha-to-coverage
decision in the extracted vk_d3d9.c.

Usage: patch_a2c_log.py <path-to-vk_d3d9.c>

FF13 draws hair/eyelashes with the A2M1/ATOC alpha-to-coverage trick. The
renderer either engages real alpha-to-coverage (multisampled render target)
or substitutes a hard alpha test at 0.5 (single-sample target). On iOS the
lashes still look like hard cutouts with MSAA on, so one run with these two
markers says which path the hair draws actually take:

    xrc-ios: A2C engaged for a draw (rt samples N)   real coverage is on
    xrc-ios: A2C fallback alpha test 0.5 for a draw  the 0.5 test ran
    (neither)                                        the game does not use
                                                     A2M1/ATOC for these draws

Each marker prints at most once per run. Idempotent per marker; fails
loudly if an anchor is not found.
"""
import sys

EDITS = [
    (
        "\t\t\t\t\tif (key.ms > 1) key.a2c = 1; else af = 7; /* (alpha to coverage: real when multisampled, else a test) */\n\t\t\t\t}",
        "\t\t\t\t\tif (key.ms > 1) key.a2c = 1; else af = 7; /* (alpha to coverage: real when multisampled, else a test) */\n\t\t\t\t}\n"
        "\t\t\t\t{ static int a2c_said; if (key.a2c && !a2c_said) { a2c_said = 1; "
        "fprintf(stderr, \"xrc-ios: A2C engaged for a draw (rt samples %u)\\n\", (unsigned)key.ms); } }",
    ),
    (
        "\t\t\tif (pc.afunc == 8 && !key.a2c && (dev.rs[154] == FOURCC('A', '2', 'M', '1') || dev.rs[181] == FOURCC('A', 'T', 'O', 'C'))) { pc.afunc = 7; pc.aref = 0.5f; }",
        "\t\t\tif (pc.afunc == 8 && !key.a2c && (dev.rs[154] == FOURCC('A', '2', 'M', '1') || dev.rs[181] == FOURCC('A', 'T', 'O', 'C'))) { static int fb_said; "
        "if (!fb_said) { fb_said = 1; fprintf(stderr, \"xrc-ios: A2C fallback alpha test 0.5 for a draw\\n\"); } pc.afunc = 7; pc.aref = 0.5f; }",
    ),
]


def main() -> int:
    path = sys.argv[1]
    with open(path, "r", encoding="utf-8", errors="replace") as f:
        text = f.read()
    changed = False
    for anchor, replacement in EDITS:
        if replacement in text:
            continue  # already in (per-marker idempotency)
        if anchor not in text:
            print(f"patch_a2c_log: anchor not found: {anchor[:60]!r}...", file=sys.stderr)
            return 1
        text = text.replace(anchor, replacement, 1)
        changed = True
    if changed:
        with open(path, "w", encoding="utf-8") as f:
            f.write(text)
        print("patch_a2c_log: markers inserted")
    else:
        print("patch_a2c_log: already applied")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
