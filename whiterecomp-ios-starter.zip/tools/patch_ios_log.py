#!/usr/bin/env python3
"""Stop WhiteRecomp v0.0.12's log_to_file() from hijacking stderr on iOS.

v0.0.12's main() starts with `#ifdef __APPLE__ log_to_file();` -- on macOS
it freopen()s stderr to "<executable>.log" beside the binary. iOS is
__APPLE__ too, and in a sideloaded install the .app directory is writable
enough for that freopen to SUCCEED: from then on the whole runtime log
(markers, window/swapchain lines, everything) goes to WhiteRecomp.log
inside the app bundle, where we cannot read it, and the ff13.log our shim
redirected stderr to in Documents goes silent right after "calling
SDL_main" -- the game runs (music, title screen) but we are blind.

Steer the call site with `&& !defined(XRC_IOS)` (build_ios.sh compiles
the runtime with -DXRC_IOS): stderr stays in Documents/ff13.log.

Idempotent; fails loudly if the anchor is not found.

Usage: patch_ios_log.py <path-to-xrc_rt.c>
"""
import sys

OLD = "#ifdef __APPLE__\n\tlog_to_file();\n#endif"
NEW = "#if defined(__APPLE__) && !defined(XRC_IOS)\n\tlog_to_file();\n#endif"


def main() -> int:
    path = sys.argv[1]
    with open(path, "r", encoding="utf-8", errors="replace") as f:
        text = f.read()
    if NEW in text:
        print("patch_ios_log: already applied")
        return 0
    if OLD not in text:
        print("patch_ios_log: anchor not found (log_to_file call site)", file=sys.stderr)
        return 1
    text = text.replace(OLD, NEW, 1)
    with open(path, "w", encoding="utf-8") as f:
        f.write(text)
    print("patch_ios_log: log_to_file() disabled on iOS (stderr stays in ff13.log)")
    return 0


if __name__ == "__main__":
    sys.exit(main())
