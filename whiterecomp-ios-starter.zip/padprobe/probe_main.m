/* probe_main.m -- PadProbe, stage 2: the smallest iOS app that asks
 * Apple's GameController framework what it sees -- now with the
 * game's SDL2.framework linked in, and SDL initialized a few seconds
 * in, to find out which layer of the game binary blinds it.
 *
 * Stage 1 (no SDL) saw the pad perfectly: "GameSir-X5 Lite_S",
 * Switch Pro Controller, extended gamepad, connect notification and
 * all. The game -- same phone, same pad, same SideStore signing --
 * reports 0 controllers from its own GameController probe at every
 * moment. The game's platform shim (ios_env.m) is innocent (setenv,
 * freopen, mkdir), so the suspects are what else the game process
 * carries: the linked SDL2.framework (dyld runs its initializers at
 * launch, before any of our code) and SDL's own iOS joystick driver
 * once initialized (built from source in this kit -- if its
 * GameController half is missing, SDL sees the accelerometer, which
 * comes from a different code path, and no controllers; that is
 * exactly the game's SDL census).
 *
 * The screen IS the report, in three readings:
 *   GC at launch      GameController before SDL_Init is ever called
 *                     (SDL2.framework linked, initializers run).
 *                     0 here = merely linking SDL poisons it.
 *   GC after SDL_Init still GameController, asked again.
 *   SDL joysticks     SDL's own enumeration, with IsGameController
 *                     per device. GC fine + SDL blind here = SDL's
 *                     driver/build is the broken layer, and the fix
 *                     belongs to the SDL build, not the game.
 */
#import <UIKit/UIKit.h>
#import <GameController/GameController.h>

#define SDL_MAIN_HANDLED 1
#include <SDL.h>

#include <stdio.h>

static UILabel *g_label;
static UIView *g_root;
static NSString *g_lastEvent = @"(none yet)";
static int g_ticks;
static int g_gcAtLaunch = -1;
static BOOL g_sdlTried;
static NSString *g_sdlInit = @"not yet";
static NSString *g_step = @"waiting";
static BOOL g_updateRan;
static BOOL g_pumpRan;

static void refresh(void) {
    NSArray<GCController *> *cs = [GCController controllers];
    NSMutableString *s = [NSMutableString string];
    [s appendFormat:@"Pad Probe 2 (+SDL)\n\n"];
    if (g_gcAtLaunch < 0) g_gcAtLaunch = (int)[cs count];
    [s appendFormat:@"GC at launch: %d\nGC now: %lu\n",
         g_gcAtLaunch, (unsigned long)[cs count]];
    for (GCController *c in cs) {
        [s appendFormat:@"- %@ (%@, extended %@)\n",
             [c vendorName] ?: @"(no name)",
             [c productCategory] ?: @"?",
             [c extendedGamepad] ? @"yes" : @"no"];
    }
    [s appendString:@"\n"];
    [s appendFormat:@"SDL_Init: %@\nstep: %@\n", g_sdlInit, g_step];
    if (!g_sdlTried) {
        [s appendString:@"SDL: not initialized yet\n"];
    } else if (!g_updateRan) {
        [s appendString:@"SDL: update not yet called\n"];
    } else {
        int i, n = SDL_NumJoysticks();
        [s appendFormat:@"SDL joysticks: %d\n", n];
        for (i = 0; i < n; i++) {
            const char *nm = SDL_JoystickNameForIndex(i);
            [s appendFormat:@"- [%d] %s gamecontroller %d\n", i,
                 nm ? nm : "?", (int)SDL_IsGameController(i)];
        }
    }
    [s appendFormat:@"\nlast event: %@\nseconds running: %d\n",
         g_lastEvent, g_ticks];
    g_label.text = s;
    g_root.backgroundColor = [cs count] > 0
        ? [UIColor colorWithRed:0.10 green:0.45 blue:0.15 alpha:1.0]
        : [UIColor colorWithRed:0.50 green:0.12 blue:0.12 alpha:1.0];
    fprintf(stderr, "padprobe: GC %lu, SDL %s\n",
            (unsigned long)[cs count],
            g_sdlTried ? "initialized" : "not yet");
}

@interface ProbeAppDelegate : NSObject <UIApplicationDelegate>
@end

@interface ProbeSceneDelegate : NSObject <UIWindowSceneDelegate>
@property(nonatomic, strong) UIWindow *window;
@end

@implementation ProbeAppDelegate

- (BOOL)application:(UIApplication *)application
    didFinishLaunchingWithOptions:(NSDictionary *)launchOptions {
    return YES;
}

- (UISceneConfiguration *)application:(UIApplication *)application
    configurationForConnectingSceneSession:
        (UISceneSession *)connectingSceneSession
                                   options:(UISceneConnectionOptions *)options {
    UISceneConfiguration *config = [[UISceneConfiguration alloc]
        initWithName:@"Default Configuration"
         sessionRole:connectingSceneSession.role];
    config.delegateClass = [ProbeSceneDelegate class];
    return config;
}

@end

@implementation ProbeSceneDelegate

- (void)xrc_event:(NSNotification *)note {
    g_lastEvent = [note name];
    refresh();
}

- (void)scene:(UIScene *)scene
    willConnectToSession:(UISceneSession *)session
                 options:(UISceneConnectionOptions *)connectionOptions {
    if (![scene isKindOfClass:[UIWindowScene class]]) return;
    UIWindowScene *ws = (UIWindowScene *)scene;
    self.window = [[UIWindow alloc] initWithWindowScene:ws];
    UIViewController *vc = [[UIViewController alloc] init];
    g_root = vc.view;
    g_label = [[UILabel alloc] initWithFrame:g_root.bounds];
    g_label.numberOfLines = 0;
    g_label.textColor = [UIColor whiteColor];
    g_label.font = [UIFont monospacedSystemFontOfSize:14
                                              weight:UIFontWeightRegular];
    g_label.autoresizingMask =
        UIViewAutoresizingFlexibleWidth | UIViewAutoresizingFlexibleHeight;
    [g_root addSubview:g_label];
    self.window.rootViewController = vc;
    [self.window makeKeyAndVisible];

    [[NSNotificationCenter defaultCenter]
        addObserver:self
           selector:@selector(xrc_event:)
               name:GCControllerDidConnectNotification
             object:nil];
    [[NSNotificationCenter defaultCenter]
        addObserver:self
           selector:@selector(xrc_event:)
               name:GCControllerDidDisconnectNotification
             object:nil];
    [GCController startWirelessControllerDiscoveryWithCompletionHandler:nil];
    refresh();
    [NSTimer scheduledTimerWithTimeInterval:1.0
                                    repeats:YES
                                      block:^(NSTimer *t) {
                                          /* Stage 3 crashed at ~3 s, in
                                           * or just after the first pump
                                           * calls. Stage 4 spreads the
                                           * calls one per second, label
                                           * updated BEFORE each first
                                           * call, so a frozen screen
                                           * names the call that died.
                                           * Init now includes VIDEO, like
                                           * the game (its renderer inits
                                           * video; pads come after). */
                                          g_ticks++;
                                          if (!g_sdlTried && g_ticks >= 2) {
                                              g_step = @"calling SDL_Init...";
                                              refresh();
                                              g_sdlTried = YES;
                                              if (SDL_Init(SDL_INIT_VIDEO |
                                                           SDL_INIT_GAMECONTROLLER) == 0) {
                                                  g_sdlInit = @"OK";
                                              } else {
                                                  g_sdlInit = [NSString
                                                      stringWithFormat:@"FAILED: %s",
                                                      SDL_GetError()];
                                              }
                                              g_step = @"SDL_Init returned";
                                          } else if (g_sdlTried && !g_updateRan &&
                                                     [g_sdlInit isEqualToString:@"OK"] &&
                                                     g_ticks >= 3) {
                                              g_step = @"calling SDL_GameControllerUpdate...";
                                              refresh();
                                              SDL_GameControllerUpdate();
                                              g_updateRan = YES;
                                              g_step = @"update returned";
                                          } else if (g_updateRan && !g_pumpRan &&
                                                     g_ticks >= 4) {
                                              g_step = @"calling SDL_PumpEvents...";
                                              refresh();
                                              SDL_PumpEvents();
                                              g_pumpRan = YES;
                                              g_step = @"pump returned";
                                          } else if (g_pumpRan) {
                                              SDL_PumpEvents();
                                              SDL_GameControllerUpdate();
                                          }
                                          refresh();
                                      }];
}

@end

int main(int argc, char *argv[]) {
    setvbuf(stderr, NULL, _IONBF, 0);
    /* Stage 4's SDL_Init error named this itself: without
     * SDL_SetMainReady(), SDL's iOS video driver refuses to init in
     * an app that brings its own delegate ("did you include
     * SDL_main.h..."). The game calls it; stages 2-4 didn't, so
     * their SDL_Init failed and the stage-3 "crash" was the update
     * calls landing on an uninitialized SDL. */
    SDL_SetMainReady();
    @autoreleasepool {
        return UIApplicationMain(argc, argv, nil,
                                 NSStringFromClass([ProbeAppDelegate class]));
    }
}
