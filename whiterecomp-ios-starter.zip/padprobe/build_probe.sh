#!/bin/sh
# build_probe.sh -- build PadProbe.ipa (stage 2: with the game's
# SDL2.framework linked; see probe_main.m for why). Run on a Mac with
# Xcode, after ios/fetch_deps.sh has fetched the deps:
#     sh padprobe/build_probe.sh
# Produces padprobe/PadProbe.ipa (unsigned; install with SideStore,
# exactly like the game, so the signing path is the same). It installs
# over the stage-1 PadProbe (same bundle id).
set -eu
cd "$(dirname "$0")"

[ "$(uname)" = "Darwin" ] || { echo "build_probe.sh must run on a Mac (Xcode provides the iOS SDK and clang)."; exit 1; }
MIN_IOS=17.0
SDK="$(xcrun --sdk iphoneos --show-sdk-path)" || { echo "no iPhoneOS SDK: install Xcode and its iOS platform."; exit 1; }
CC="$(xcrun --sdk iphoneos -f clang)"

SDL_SLICE="$PWD/../ios/deps/SDL2.xcframework/ios-arm64"
[ -d "$SDL_SLICE/SDL2.framework" ] || { echo "SDL2.xcframework not found in ios/deps -- run sh ios/fetch_deps.sh first."; exit 1; }

WORK="$PWD/build"
rm -rf "$WORK"
mkdir -p "$WORK/Payload/PadProbe.app/Frameworks"
cp -R "$SDL_SLICE/SDL2.framework" "$WORK/Payload/PadProbe.app/Frameworks/"

"$CC" --target="arm64-apple-ios$MIN_IOS" -isysroot "$SDK" \
    "-miphoneos-version-min=$MIN_IOS" -O1 \
    -F"$SDL_SLICE" -I"$SDL_SLICE/SDL2.framework/Headers" \
    -Wl,-rpath,@executable_path/Frameworks \
    -o "$WORK/Payload/PadProbe.app/PadProbe" probe_main.m \
    -framework SDL2 \
    -framework UIKit -framework GameController -framework Foundation \
    -framework QuartzCore -framework CoreGraphics

cp ProbeInfo.plist "$WORK/Payload/PadProbe.app/Info.plist"

( cd "$WORK" && zip -q -r ../PadProbe.ipa Payload )
rm -rf "$WORK"
echo "built $PWD/PadProbe.ipa -- install it over the old PadProbe with SideStore, clamp the pad on, open it."
