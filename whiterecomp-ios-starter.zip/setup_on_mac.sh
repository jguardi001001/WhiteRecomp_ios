#!/bin/sh
# setup_on_mac.sh -- run on your Mac, from inside this folder:
#     sh setup_on_mac.sh
# It downloads the official WhiteRecomp v0.0.13 macOS launcher (158 MB,
# from ps4star's GitHub release), and extracts the game sources out of it
# into src/bundle/ (796 MB -- make sure you have ~3 GB free). After this:
#     sh ios/fetch_deps.sh     (only needed once, on a fresh folder)
#     sh ios/build_ios.sh
# Upgrading from the v0.0.9 kit: just run this again in the same folder --
# it replaces the launcher in original/ and the extracted sources in
# src/bundle/ with the v0.0.13 ones (a version stamp in src/bundle/
# tracks which is which; the old bundle is removed, not merged).
set -eu
cd "$(dirname "$0")"

BUNDLE_VERSION="0.0.13"
STAMP="src/bundle/.xrc_bundle_version"

if [ ! -f original/WhiteRecompLauncher_macos_v0.0.13.zip ]; then
    echo "== downloading WhiteRecomp v0.0.13 macOS launcher =="
    mkdir -p original
    curl -L -o original/WhiteRecompLauncher_macos_v0.0.13.zip \
        https://github.com/ps4star/WhiteRecomp/releases/download/v0.0.13/WhiteRecompLauncher_macos.zip
    echo "1d28f36292f1ff55521152215aa1e59a6f439534cd93c4f2ef83f2816df46003  original/WhiteRecompLauncher_macos_v0.0.13.zip" | shasum -a 256 -c -
fi
if [ ! -f "$STAMP" ] || [ "$(cat "$STAMP")" != "$BUNDLE_VERSION" ]; then
    echo "== unpacking the v0.0.13 launcher =="
    rm -rf original/WhiteRecomp.app
    unzip -o -q original/WhiteRecompLauncher_macos_v0.0.13.zip -d original
    echo "== extracting the v0.0.13 source bundle (this takes a minute) =="
    rm -rf src/bundle
    python3 tools/extract_bundle.py original/WhiteRecomp.app/Contents/MacOS/ff13-launcher src/bundle
    printf '%s\n' "$BUNDLE_VERSION" > "$STAMP"
fi

echo ""
echo "setup done (bundle v$BUNDLE_VERSION). Next:"
echo "  sh ios/build_ios.sh    (fetch_deps.sh first, only on a fresh folder)"
