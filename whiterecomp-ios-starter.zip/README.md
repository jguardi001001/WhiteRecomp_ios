# WhiteRecomp → iOS port (in progress)

Porting **FINAL FANTASY XIII** (WhiteRecomp, by ps4star) to iPhone/iPad,
starting from the official macOS launcher — **v0.0.12** as of 2026-11-22
(upgraded from v0.0.9; see `UPGRADE_V0012_PLAN.md`) — not from fnxf_xiii /
nxnative (different game source, incompatible stack; see the checks in
chat, 2026-11-21).

## Status (2026-11-21)

| Step | State |
|---|---|
| v0.0.9 macOS launcher preserved + hashed | ✅ `original/` (zip SHA-256 `4be21434…358d`) |
| Bundle extractor written | ✅ `tools/extract_bundle.py` |
| Full source bundle extracted | ✅ `src/bundle/` — 3,153 files, 519.8 MB: `gen/` translated game C, `runtime/`, `include/xrc.h`, Vulkan headers, FFmpeg headers/libs (macOS), `cross/` sysroots (Android/Linux only), PGO profile |
| Build recipe mapped from the launcher's own code | ✅ see below |
| Extracted sources compile-checked | ✅ 8/8 representative units build clean on Linux gcc with the launcher's flags: a game page, `xrc_table.c`, `xrc_rt.c`, the Vulkan renderer `vk_d3d9.c`, HLE, audio, movie, an override |
| iOS scaffolding | ✅ `ios/` — build script, deps script, entry point, platform shim, Info.plist, entitlements, cfg |
| iOS build itself | ⏳ **needs a Mac with Xcode** (this workspace is a Linux VM — no iPhoneOS SDK here) |
| On-device test | ⏳ after the Mac build |

## Why this can work (what the sources showed)

- The game is plain C with a normal `main()` in `runtime/xrc_rt.c`, and the
  runtime is already Apple-aware (`__APPLE__` branches, `xrc_posix.h`
  compat for macOS pthread differences, guest memory = `mmap` with
  `MAP_NORESERVE`, no fixed base on Apple).
- Graphics/input/audio go through the **SDL branch** of `vk_d3d9.c` on
  every non-Windows, non-Android target — SDL creates the window and the
  Vulkan surface (`SDL_Vulkan_CreateSurface`), which on iOS is a Metal
  surface via MoltenVK. The renderer already handles MoltenVK's
  `VK_KHR_portability_subset`, falls back when `VK_KHR_push_descriptor`
  is missing, and accepts Vulkan 1.1 + `VK_KHR_dynamic_rendering`.
- SDL2 and the Vulkan loader are **dlopened at runtime**, located via the
  `XRC_SDL_LIB` / `XRC_VK_LIB` environment variables — so the iOS shim
  just points them at the app bundle's `Frameworks/`.
- Android is the template: `runtime/xrc_android.c` sets `XRC_GAME_DIR`,
  `XRC_EXE`, `XRC_CDRIVE`, `XRC_NO_STEAM=1`, `XRC_MOVIE_NO_CONVERT=1`
  before calling the game's `main()`, and the cross build forces phone
  settings (30 fps, 512 shadows, MSAA 0, half-res effects). The iOS shim
  (`ios/src/ios_env.m`, a constructor) does the same for iOS paths, and
  `ios/src/ios_main.c` enters via SDL's `SDL_UIKitRunApp` with the game's
  main renamed to `SDL_main`.

## Build recipe (mirrors launcher_src/build_game.odin)

Pages `gen/src/*.c`: `-O1 -ffast-math -fno-associative-math -fno-strict-aliasing -fwrapv -Iinclude`
Runtime + table + overrides: same common flags + `-DXRC_VULKAN -DXRC_FRAME_LIMIT=30 -Iinclude -Iruntime -Iffmpeg/include -Ivulkan/include`
Skipped: `runtime/ref_*.c` (Windows reference target), `runtime/xrc_android.c` (Android shim).
Link: all objects + FFmpeg static libs (`avformat, avcodec, swresample, avutil`) + SDL2 (for `SDL_UIKitRunApp`).

iOS target form: `--target=arm64-apple-ios17.0 -isysroot <iPhoneOS SDK> -mcpu=apple-m1` (the launcher's own Apple-silicon baseline).

## How to build (on a Mac)

```sh
sh ios/fetch_deps.sh     # SDL2 + MoltenVK XCFrameworks; builds FFmpeg for iphoneos
sh ios/build_ios.sh      # -> WhiteRecomp.ipa (unsigned)
```

Rerunning `build_ios.sh` is incremental — objects in `build-ios/obj/` are
reused and only sources newer than their `.o` are recompiled, so a rerun
after a link-stage failure jumps straight to the link. `CLEAN=1 sh
ios/build_ios.sh` forces a full rebuild (also do that after editing the
compile flags in the script, or a header in `src/bundle/`).

Sign/install with AltStore / SideStore / Xcode, applying
`ios/WhiteRecomp.entitlements` (increased memory + extended virtual
addressing — the runtime reserves a 4 GB guest address space; if a free
personal-team signature strips them, set `XRC_GUEST_2GB=1` in
`ios/src/ios_env.m` and rebuild).

Then copy your **`FINAL FANTASY XIII`** folder (Steam install from a
Windows PC, movies pre-converted there if you want cutscenes) into the
app's Documents via the Files app, and launch. The log lands in
`Documents/ff13.log`.

## Known risks / first-debug list

1. **MoltenVK on iOS** — dynamic rendering + synchronization2 under the
   iOS Metal feature set; the renderer's fallbacks cover some of it, the
   rest is first-run debugging.
2. **Guest memory** — 4 GB `MAP_NORESERVE` reservation vs iOS VA/jetsam
   limits; entitlements above, 2 GB mode as fallback.
3. **macOS build is untested upstream** — the Apple/SDL path itself may
   have bugs that only surface now, on iOS.
4. **No touch controls yet** — Android's overlay lives in its shim +
   renderer hooks (`xrc_android.h` events). v1 expects a game controller;
   porting the touch overlay is the follow-up (the layout/drawing code is
   platform-free C in the runtime).
5. **SDL_main linking** — if the SDL2 XCFramework's dynamic slice lacks
   `SDL_UIKitRunApp`, use SDL's static `libSDL2main` from the same
   release in `ios_main.c`'s place.
