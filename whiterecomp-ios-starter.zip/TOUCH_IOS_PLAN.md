# Touch controls for iOS — plan (implemented 2026-11-21, awaiting on-device test)

Implementation note: the pad route differs from the plan below. Reading
hle_dinput.c showed its Android backend REPLACES the SDL one, which on
iOS would have killed real controllers — so ios/src/xrc_ios_touch.c
keeps the Android state machine and overlay exactly, but presses an
SDL virtual game controller instead of an XrcAPad, and hle_dinput.c is
untouched. Guards are opened by tools/patch_touch.py (run from
build_ios.sh). Compile-checked on Linux against the real SDL 2.32.10
headers and the patched vk_d3d9.c; the plan below is the original
design record.

Written 2026-11-21, from reading the extracted v0.0.9 bundle in `src/bundle/`.
Do NOT start this until the game itself runs on iOS with a controller and
`ff13.log` confirms Vulkan/MoltenVK is up. v1 (current build) expects a
controller; this is the follow-up that removes that requirement.

## What already exists (Android) — reuse it, don't rewrite it

The whole touch system exists in the bundle, but every piece is gated on
`__ANDROID__`:

- Layout / state / sticks: `src/bundle/runtime/xrc_android.c:147-285`
  (`xrc_touch_layout` 155-162, `xrc_touch_stick_reach`, `touch_show`,
  `touch_hit`, `stick_move`/`stick_end`, `touch_publish`, `touch_event`).
  Buttons: A, B, "0" (Start), "1" (Back). Two floating sticks: a finger
  down anywhere off the buttons makes a stick where it lands — left half
  = move, right half = camera. Shown from the start, hidden when a real
  controller is used. `XRC_TOUCH=0` disables it.
- API: `src/bundle/runtime/xrc_android.h:36-52` (`XrcTouchCtl`,
  `xrc_touch_layout`, `xrc_touch_state`, `xrc_touch_stick`,
  `xrc_touch_version`), all inside `#ifdef __ANDROID__` (line 6).
- Drawing: `src/bundle/runtime/vk_d3d9.c:4573-4714` (`touch_overlay`,
  CPU-rasterised RGBA overlay via `touch_font.h` + stb_truetype, blended
  over the back buffer), called at `vk_d3d9.c:4741-4742`, also
  `#ifdef __ANDROID__`. It only needs `xrc_touch_*` + `xrc_view_w/h` —
  nothing Android-specific.
- The pad the game sees: `xrc_android.c:148,151` — a static `XrcAPad`
  `tpad` ("Touch controls", id -1000), exposed as pad 0 by
  `xrc_android_pad()`. `hle_dinput.c:267-295` shows it to the game as
  device 0 under `#ifdef __ANDROID__`, in SDL controller numbering
  (axes 0-3 sticks, 4-5 triggers; buttons 0 A, 1 B, 4 Back, 6 Start).

## What iOS is missing

- The iOS path uses the SDL branch of `vk_d3d9.c` (`#else`, ~line 340+).
  Its `pump_events` (~378-446) handles only SDL_QUIT (0x100),
  WINDOWEVENT (0x200), KEYDOWN/UP (0x300/0x301), MOUSEMOTION (0x400),
  MOUSEBUTTONDOWN/UP (0x401/0x402), MOUSEWHEEL (0x403). There is no
  handling of SDL finger events (SDL_FINGERDOWN 0x700, SDL_FINGERUP
  0x701, SDL_FINGERMOTION 0x702).
- `ios/src/ios_env.m` sets no `XRC_TOUCH` and no `XRC_PAD_VIRTUAL`.

## Proposed shape (to be done on the Mac, with the game running)

1. New file `ios/src/xrc_ios_touch.c` (or `runtime/xrc_ios_touch.c`,
   compiled only for iOS): the touch logic copied from
   `xrc_android.c:147-285`, with the Android-only parts swapped out:
   - `touch_to_picture`: replace `ANativeWindow_getWidth/Height` with
     the window size `pump_events` already reads via `SDL_GetWindowSize_`
     (same `xrc_view_map` call, `xrc_rt.h:104-110`).
   - `touch_event`: replace `AInputEvent` with SDL finger events —
     finger id, normalised x/y (0..1) -> window points -> picture pixels.
     vk_d3d9.c's SDL branch uses raw numeric event codes and byte
     offsets (no SDL headers included); do the same, and verify the
     `SDL_TouchFingerEvent` field offsets against the SDL2 headers in
     `ios/deps/SDL2.xcframework` on the Mac before trusting them.
   - Keep the `XrcAPad`-shaped pad (`tpad`) and the `xrc_touch_*`
     function names, so the overlay and `hle_dinput` need no logic
     changes — only their guards change.
2. Generalise the guards, not a fork: introduce one define (e.g.
   `XRC_TOUCH_PAD`, set for `__ANDROID__` and for the iOS build) and use
   it in place of `__ANDROID__` at `xrc_android.h:6`,
   `vk_d3d9.c:4573, 4719, 4741`, and `hle_dinput.c:267, 290`. Keep the
   Android NDK parts of `xrc_android.c` (activity, JNI, AInputEvent)
   untouched — the iOS file is a separate, small file.
3. Hide the overlay when a real controller is used, as Android does
   (`touch_show(0)` on controller input). On iOS the SDL controller
   path in `hle_dinput.c` already reports real controllers; hook the
   hide/show to that, or at minimum to "any SDL controller button/axis
   event arrives".
4. Build flag: keep it behind the existing `XRC_TOUCH` env var (0 =
   off, touch is the mouse as before), so a bad touch build can be
   disabled without rebuilding. `build_ios.sh` compiles the new file
   alongside `ios_main.c` / `ios_env.m`; no change to the game pages.

## Alternative considered (not recommended first)

Drive SDL's virtual controller instead: `hle_dinput.c:311-318` already
attaches one when `XRC_PAD_VIRTUAL=1`, but it only dlsyms
`SDL_JoystickSetVirtualButton` — there is no `SDL_JoystickSetVirtualAxis`
wired up, so the sticks would need new plumbing, and the overlay drawing
would still need the guard change above. The Android-pad route reuses
more existing code. Keep the virtual-controller route as a fallback if
the pad generalisation fights the SDL controller enumeration.

## Unknowns to settle on device (do not guess)

- Does SDL on iOS already turn a tap into SDL mouse-button events?
  If it does, menus may already be tappable today and only the
  gamepad buttons/sticks are missing. Check `ff13.log` / a quick
  probe before writing the finger-event path.
- SDL finger-event struct offsets in the SDL 2.32 headers shipped in
  `ios/deps` (see step 1).
- Whether the overlay's half-size RGBA blit performs acceptably on
  iPhone (it is CPU-rasterised only when what is held changes).
- iPad vs iPhone layout: the Android layout is sized by picture
  height, so it should scale, but verify the buttons are reachable
  in both orientations.

## Test sequence (Mac + iPhone, game data installed)

1. Rebuild with the touch file; launch with a controller paired —
   overlay must stay hidden, controller must still work.
2. Disconnect the controller, touch the screen — overlay appears,
   A/B/Start/Back respond, left stick moves the character, right
   stick moves the camera.
3. `XRC_TOUCH=0` in `WhiteRecomp.cfg` — no overlay, touch is the
   mouse as in v1.
4. Keep the v1 IPA that works with a controller until step 2 passes;
   do not overwrite it.
