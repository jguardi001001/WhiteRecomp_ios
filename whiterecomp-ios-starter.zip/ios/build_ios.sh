#!/bin/sh
# build_ios.sh -- build WhiteRecomp (FINAL FANTASY XIII) for iOS from the
# sources extracted out of the official v0.0.9 macOS launcher, and pack an
# UNSIGNED .ipa (sign it with AltStore / SideStore / Xcode afterwards).
#
# This mirrors the official launcher's own build (launcher_src/
# build_game.odin in ps4star/WhiteRecomp) unit for unit, with the flags
# translated to an iOS cross build -- the same trick its Cross-Compile tab
# uses for Android, with ios/src/ios_env.m + ios_main.m standing in for
# runtime/xrc_android.c's NativeActivity shim:
#
#   pages    gen/src/*.c            page flags (below)
#   table    gen/xrc_table.c        runtime flags
#   matched  gen/match/*.c          page flags + runtime headers
#   runtime  runtime/*.c            runtime flags; ref_*.c skipped (they are
#            (except ref_*,            the Windows reference target) and
#             xrc_android.c)           xrc_android.c skipped (Android only)
#   overrides gen/src/overrides/*.c runtime flags
#   entry    ios/src/ios_main.m     own UIApplicationMain + delegate that
#                                   calls SDL_main directly (SDL_UIKitRunApp's
#                                   delegate chain never fired under
#                                   LiveContainer -- see ios_main.m)
#            runtime/xrc_rt.c is compiled with -Dmain=SDL_main
#   shim     ios/src/ios_env.m      constructor: XRC_* paths (Documents)
#
# Differences from the desktop build, deliberately:
#   -DXRC_FRAME_LIMIT=60 (the player asked for 60 over the phone preset's
#     30) and the Android phone preset (shadows 512, MSAA 0, half-res
#     effects) -- the launcher forces the same for Android.
#   No PGO yet: the bundle's pgo/ff13.profdata was recorded on desktop
#     targets; the launcher probes a compiler before using a profile
#     (pgo_prepare) -- first bring-up builds without it.
#   FFmpeg comes from ios/deps (built for iphoneos by fetch_deps.sh); the
#     bundle's ffmpeg/lib is macOS binaries and cannot link for iOS.
#   SDL2 and MoltenVK are NOT linked into the game (except SDL_UIKitRunApp):
#     the runtime dlopens them, at the paths ios_env.m puts in XRC_SDL_LIB /
#     XRC_VK_LIB, exactly as the macOS build points them at the .app's
#     Frameworks.
#
# Env knobs: OPT=1 (default; the launcher's recommended level), JOBS=n,
#   MIN_IOS=17.0, OUT=WhiteRecomp.ipa, CLEAN=1 (force a full rebuild)
# Incremental builds: objects in build-ios/obj/ survive reruns -- a rerun
# after a link-stage failure only recompiles sources newer than their .o
# (the ~250 game/runtime files take minutes; the link takes seconds).
# A flags stamp (OPT/MIN_IOS) in build-ios/obj/.flags forces a full
# rebuild when those change. If you edit the compile flags inside this
# script, run CLEAN=1 once -- the stamp does not see those edits.
set -eu
cd "$(dirname "$0")/.."                       # project root
ROOT="$PWD"
SRC="$ROOT/src/bundle"
IOS="$ROOT/ios"
DEPS="$IOS/deps"
OPT="${OPT:-1}"
MIN_IOS="${MIN_IOS:-17.0}"
JOBS="${JOBS:-$(sysctl -n hw.ncpu 2>/dev/null || echo 4)}"
OUT="${OUT:-$ROOT/WhiteRecomp.ipa}"

[ "$(uname)" = "Darwin" ] || { echo "build_ios.sh must run on a Mac (Xcode provides the iOS SDK and clang)."; exit 1; }
SDK="$(xcrun --sdk iphoneos --show-sdk-path)" || { echo "no iPhoneOS SDK: install Xcode and its iOS platform."; exit 1; }
CC="$(xcrun --sdk iphoneos -f clang)"

if [ ! -d "$SRC/gen/src" ]; then
    echo "extracted sources missing: running the extractor on the v0.0.12 launcher..."
    python3 "$ROOT/tools/extract_bundle.py" \
        "$ROOT/original/WhiteRecomp.app/Contents/MacOS/ff13-launcher" "$SRC"
fi
# stage markers in the game's main() (idempotent; see tools/patch_markers.py)
python3 "$ROOT/tools/patch_markers.py" "$SRC/runtime/xrc_rt.c"
# keep the runtime log in Documents/ff13.log: v0.0.12's main() freopen()s
# stderr into the .app bundle on __APPLE__ (idempotent; see
# tools/patch_ios_log.py)
python3 "$ROOT/tools/patch_ios_log.py" "$SRC/runtime/xrc_rt.c"
# touch controls for iOS (idempotent; see tools/patch_touch.py and
# ios/src/xrc_ios_touch.c)
python3 "$ROOT/tools/patch_touch.py" "$SRC/runtime/vk_d3d9.c" "$SRC/runtime/xrc_android.h"
# keep iOS on the SDL window path: v0.0.12's macOS Cocoa window branch is
# selected by __APPLE__, which also matches iOS (idempotent; see
# tools/patch_ios_window.py). The alpha-to-coverage hair fix is upstream
# in v0.0.12 now, so the old patch_a2c_fix.py backport is retired.
python3 "$ROOT/tools/patch_ios_window.py" "$SRC/runtime/vk_d3d9.c"
for d in SDL2.xcframework MoltenVK.xcframework ffmpeg/lib/libavcodec.a; do
    [ -e "$DEPS/$d" ] || { echo "missing ios/deps/$d -- run ios/fetch_deps.sh first."; exit 1; }
done

SDL_FW="$DEPS/SDL2.xcframework/ios-arm64/SDL2.framework"
MVK_FW="$DEPS/MoltenVK.xcframework/ios-arm64/MoltenVK.framework"
[ -d "$SDL_FW" ] || { echo "SDL2.xcframework has no ios-arm64 slice at $SDL_FW"; exit 1; }
[ -d "$MVK_FW" ] || { echo "MoltenVK.xcframework has no ios-arm64 slice at $MVK_FW"; exit 1; }

OBJ="$ROOT/build-ios/obj"
APP="$ROOT/build-ios/Payload/WhiteRecomp.app"
mkdir -p "$OBJ"
# Only the .app is rebuilt from scratch each run (cp -R over an existing
# framework would nest it inside itself); the objects stay. CLEAN=1 or a
# changed OPT/MIN_IOS stamp wipes them for a full rebuild.
if [ "${CLEAN:-0}" = "1" ]; then rm -f "$OBJ"/*.o "$OBJ"/.flags; fi
_CUR_FLAGS="OPT=$OPT MIN_IOS=$MIN_IOS TOUCH=1 FRAME=60 V0013=6"
if [ -f "$OBJ/.flags" ] && [ "$(cat "$OBJ/.flags")" != "$_CUR_FLAGS" ]; then
    echo "build flags changed ($_CUR_FLAGS): full rebuild"
    rm -f "$OBJ"/*.o
fi
printf '%s\n' "$_CUR_FLAGS" > "$OBJ/.flags"
rm -rf "$APP"
mkdir -p "$APP/Frameworks"

# Flags are passed as function arguments, never as unquoted strings: the
# project folder may contain spaces ("whiterecomp-ios 3"), and a split
# -I path is exactly the failure that produces. v1 used flag strings and
# broke that way; do not regress to them.
cc_ios() { # target prefix shared by every compile/link below
    "$CC" --target="arm64-apple-ios$MIN_IOS" -isysroot "$SDK" \
        "-miphoneos-version-min=$MIN_IOS" "$@"
}
# the launcher's common_flags, iOS form: macOS uses -mcpu=apple-m1 as the
# Apple-silicon baseline; fast-math without reassociation (the game's own
# rounding tricks break otherwise -- options.odin).
cc_base() {
    cc_ios -mcpu=apple-m1 -ffast-math -fno-associative-math \
        -fno-stack-protector -fno-addrsig "-O$OPT" -w "$@"
}

_n=0
_skipped=0
_run() { # run in background, in batches of $JOBS (plain `wait`: macOS
         # /bin/sh is bash 3.2, which has no `wait -n`)
    "$@" &
    _n=$((_n + 1))
    if [ "$_n" -ge "$JOBS" ]; then wait; _n=0; fi
}
_up_to_date() { # src obj: true when the object exists and is newer than
                # its source. Sources here are the extracted bundle, whose
                # headers do not change between runs, so source mtime is
                # the right trigger; use CLEAN=1 after editing a header.
    [ -f "$2" ] && [ "$2" -nt "$1" ]
}
compile_page() { # src obj [extra...]
    _s="$1"; _o="$2"; shift 2
    if _up_to_date "$_s" "$_o"; then _skipped=$((_skipped + 1)); return 0; fi
    echo "CC $(basename "$_s")"
    _run cc_base -fno-strict-aliasing -fwrapv -I"$SRC/include" "$@" -c "$_s" -o "$_o"
}
compile_rt() { # src obj [extra...]
    _s="$1"; _o="$2"; shift 2
    if _up_to_date "$_s" "$_o"; then _skipped=$((_skipped + 1)); return 0; fi
    echo "CC $(basename "$_s")"
    _run cc_base -I"$SRC/include" -I"$SRC/runtime" -I"$DEPS/ffmpeg/include" \
        -DXRC_VULKAN -DXRC_TOUCH_PAD -DXRC_IOS -I"$SRC/vulkan/include" -DXRC_FRAME_LIMIT=60 "$@" -c "$_s" -o "$_o"
}

# --- the units, mirroring build_game.odin --------------------------------
for f in "$SRC"/gen/src/*.c; do
    compile_page "$f" "$OBJ/$(basename "${f%.c}").o"
done
compile_rt "$SRC/gen/xrc_table.c" "$OBJ/xrc_table.o"
for f in "$SRC"/gen/match/*.c; do
    compile_page "$f" "$OBJ/m_$(basename "${f%.c}").o" -I"$SRC/runtime"
done
for f in "$SRC"/gen/src/overrides/*.c; do
    compile_rt "$f" "$OBJ/ovr_$(basename "${f%.c}").o"
done
for f in "$SRC"/runtime/*.c; do
    case "$(basename "$f")" in
        ref_*|xrc_android.c|xrc_cocoa.c) continue ;;    # Windows reference / Android shim / macOS window layer
        xrc_rt.c) compile_rt "$f" "$OBJ/rt_xrc_rt.o" -Dmain=SDL_main ;;
        *)        compile_rt "$f" "$OBJ/rt_$(basename "${f%.c}").o" ;;
    esac
done
if _up_to_date "$IOS/src/ios_main.m" "$OBJ/ios_main.o"; then
    _skipped=$((_skipped + 1))
else
    echo "CC ios_main.m"
    cc_ios -O2 -F"$DEPS/SDL2.xcframework/ios-arm64" -I"$SDL_FW/Headers" -c "$IOS/src/ios_main.m" -o "$OBJ/ios_main.o"
fi
# the touch controls (plain C: the Android design fed by SDL finger
# events, pressing an SDL virtual gamepad; needs the SDL headers the
# runtime itself only dlopens)
if _up_to_date "$IOS/src/xrc_ios_touch.c" "$OBJ/xrc_ios_touch.o"; then
    _skipped=$((_skipped + 1))
else
    echo "CC xrc_ios_touch.c"
    cc_ios -O2 -DXRC_TOUCH_PAD -I"$SRC/include" -I"$SRC/runtime" \
        -F"$DEPS/SDL2.xcframework/ios-arm64" -I"$SDL_FW/Headers" \
        -c "$IOS/src/xrc_ios_touch.c" -o "$OBJ/xrc_ios_touch.o"
fi
# the platform shim (Objective-C, no ARC: it only calls Foundation C-style)
if _up_to_date "$IOS/src/ios_env.m" "$OBJ/ios_env.o"; then
    _skipped=$((_skipped + 1))
else
    echo "CC ios_env.m"
    cc_ios -O2 -c "$IOS/src/ios_env.m" -o "$OBJ/ios_env.o"
fi
wait
[ "$_skipped" -gt 0 ] && echo "reused $_skipped up-to-date object(s)"

# --- link ------------------------------------------------------------------
echo "LD WhiteRecomp"
cc_ios -o "$APP/WhiteRecomp" "$OBJ"/*.o \
    -Wl,-rpath,@executable_path/Frameworks \
    -F"$DEPS/SDL2.xcframework/ios-arm64" -framework SDL2 \
    "$DEPS/ffmpeg/lib/libavformat.a" "$DEPS/ffmpeg/lib/libavcodec.a" \
    "$DEPS/ffmpeg/lib/libswresample.a" "$DEPS/ffmpeg/lib/libavutil.a" \
    -framework Foundation -framework CoreFoundation -framework CoreMedia \
    -framework CoreVideo -framework VideoToolbox -framework AVFoundation \
    -framework AudioToolbox -framework Security -framework UIKit -framework QuartzCore \
    -framework GameController \
    -lz -lbz2 -liconv -lm

# --- assemble the .app ------------------------------------------------------
cp "$IOS/Info.plist" "$APP/Info.plist"
cp "$IOS/AppIcon1024.png" "$APP/AppIcon1024.png"
cp "$IOS/WhiteRecomp.cfg" "$APP/WhiteRecomp.cfg"
printf 'APPL????' > "$APP/PkgInfo"
cp -R "$SDL_FW" "$APP/Frameworks/SDL2.framework"
cp -R "$MVK_FW" "$APP/Frameworks/MoltenVK.framework"

# ad-hoc sign the frameworks + app so the bundle is well-formed; the
# sideloading tool re-signs everything with the player's identity (and is
# where the increased-memory entitlements in ios/WhiteRecomp.entitlements
# get applied -- see README).
codesign --force --sign - "$APP/Frameworks/SDL2.framework" "$APP/Frameworks/MoltenVK.framework" 2>/dev/null || true
codesign --force --sign - "$APP" 2>/dev/null || true

(cd "$ROOT/build-ios" && zip -qr "$OUT" Payload)
echo "built $OUT (unsigned)"
echo "install: AltStore / SideStore, or open the .app in Xcode's Devices window after signing."
echo "then: copy your 'FINAL FANTASY XIII' folder (Steam, Windows) into the app's Documents via Files/Finder."
