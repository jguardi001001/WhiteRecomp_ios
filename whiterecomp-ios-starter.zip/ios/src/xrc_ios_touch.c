/* xrc_ios_touch.c -- the touch controls for iOS: the Android design
 * (runtime/xrc_android.c's touch controls, vk_d3d9.c's overlay) with the
 * two Android-only pieces swapped out.
 *
 * Input: SDL finger events instead of AInputEvent. vk_d3d9.c's SDL
 * pump_events forwards them to xrc_ios_touch_finger() (see
 * tools/patch_touch.py), already knowing the window's size and where
 * the picture sits in it.
 *
 * The pad the game sees: instead of Android's XrcAPad behind
 * hle_dinput.c's Android backend (which REPLACES its SDL one -- on iOS
 * that would kill real controllers), this attaches an SDL virtual
 * game controller and presses it. hle_dinput.c's ordinary SDL path
 * enumerates it like any other controller ("xrc: gamepads: controller
 * N: ..." in ff13.log), next to real ones. The overlay in vk_d3d9.c
 * draws from the same xrc_touch_* state as Android's.
 *
 * Shown from the start and whenever the screen is touched; hidden --
 * and the virtual pad detached -- once a real controller is used (its
 * events reach pump_events too). XRC_TOUCH=0: none of it, and touches
 * stay the mouse, as in v1.
 *
 * Compiled only for iOS, with -DXRC_TOUCH_PAD (which also opens
 * xrc_android.h's API and vk_d3d9.c's overlay to this file) and the
 * SDL2 framework's headers; the executable links SDL2, and the calls
 * below land in the same SDL the runtime dlopens.
 */
#include <stdlib.h>
#include <string.h>

#include "xrc_rt.h"      /* xrc_view_w / xrc_view_h */
#include "xrc_android.h" /* the shared touch API: XrcTouchCtl, XRC_TC_*, xrc_touch_* */

#define SDL_MAIN_HANDLED 1
#include <SDL.h>

/* ------------------------------------------------------------------ state
 * (the Android code's, field for field: vk_d3d9.c's overlay reads it
 * through xrc_touch_state / xrc_touch_stick / xrc_touch_version) */
static volatile unsigned touch_st; /* bit 31: shown; bits 0..3: A B Start Back held */
static volatile unsigned touch_ver;
static int touch_off = -1;         /* XRC_TOUCH=0 */
static int touch_ready;            /* the lazy init ran */
static struct { volatile int on; volatile float cx, cy, kx, ky; } stk[2];

/* the virtual gamepad (SDL_Joystick*, kept open while shown) */
static SDL_Joystick *vjoy;
static int vjoy_index = -1;
static SDL_JoystickID vjoy_id = -1;

/* the fingers on the screen: which control each holds (a button,
 * 4 + k: stick k, -1 none) */
#define TP_N 10
#define TC_STICK 4
static struct { SDL_FingerID id; int ctl; } tp[TP_N];
static int ntp;

/* ----------------------------------------------------- controller census
 * Whether a real pad works is decided by what SDL sees, so say it in
 * the log: once at start-up and whenever the joystick count changes
 * (hotplug). A pad missing here is invisible to SDL/iOS entirely (its
 * mode switch, its cable); a pad here with "gamecontroller 0" has no
 * SDL mapping, and hle_dinput skips those -- its GUID is what a
 * mapping for it would be written against. */
static int pad_census_last = -1;
static void pad_census(void) {
	int i, n = SDL_NumJoysticks();
	pad_census_last = n;
	if (n <= 0) {
		fprintf(stderr, "xrc-ios: pad census: SDL sees no joysticks\n");
		return;
	}
	for (i = 0; i < n; i++) {
		SDL_JoystickGUID g = SDL_JoystickGetDeviceGUID(i);
		char gs[64];
		const char *nm = SDL_JoystickNameForIndex(i);
		SDL_JoystickGetGUIDString(g, gs, sizeof gs);
		fprintf(stderr, "xrc-ios: pad census: [%d] \"%s\" guid %s gamecontroller %d virtual %d\n",
			i, nm ? nm : "?", gs, (int)SDL_IsGameController(i),
			(int)SDL_JoystickIsVirtual(SDL_JoystickGetDeviceInstanceID(i)));
	}
}

void xrc_touch_layout(int w, int h, XrcTouchCtl c[XRC_TC_N]) {
	float u = (float)h;
	c[XRC_TC_A].x = w - 0.12f * u;            c[XRC_TC_A].y = h - 0.15f * u;   c[XRC_TC_A].r = 0.10f * u;
	c[XRC_TC_B].x = w - 0.31f * u;            c[XRC_TC_B].y = h - 0.30f * u;   c[XRC_TC_B].r = 0.075f * u;
	c[XRC_TC_BACK].x = w * 0.5f - 0.11f * u;  c[XRC_TC_BACK].y = 0.075f * u;   c[XRC_TC_BACK].r = 0.05f * u;
	c[XRC_TC_START].x = w * 0.5f + 0.11f * u; c[XRC_TC_START].y = 0.075f * u;  c[XRC_TC_START].r = 0.05f * u;
}
float xrc_touch_stick_reach(int h) { return 0.13f * (float)h; }
static void touch_ensure_init(void);
unsigned xrc_touch_state(void) {
	/* the overlay asks every frame: also the "shown from the start"
	 * trigger, so the controls are up before the first touch */
	touch_ensure_init();
	if (SDL_NumJoysticks() != pad_census_last) pad_census();
	return __atomic_load_n(&touch_st, __ATOMIC_ACQUIRE);
}
unsigned xrc_touch_version(void) { return __atomic_load_n(&touch_ver, __ATOMIC_ACQUIRE); }
int xrc_touch_stick(int k, float *cx, float *cy, float *kx, float *ky) {
	if (!stk[k].on) return 0;
	*cx = stk[k].cx; *cy = stk[k].cy; *kx = stk[k].kx; *ky = stk[k].ky;
	return 1;
}

/* ------------------------------------------------------- the virtual pad */
static void vjoy_write(void) {
	/* buttons from what the fingers hold (SDL's numbering, as in
	 * touch_publish on Android: 0 A, 1 B, 4 Back, 6 Start) */
	unsigned st = __atomic_load_n(&touch_st, __ATOMIC_ACQUIRE);
	if (!vjoy) return;
	SDL_JoystickSetVirtualButton(vjoy, 0, (st >> XRC_TC_A) & 1);
	SDL_JoystickSetVirtualButton(vjoy, 1, (st >> XRC_TC_B) & 1);
	SDL_JoystickSetVirtualButton(vjoy, 6, (st >> XRC_TC_START) & 1);
	SDL_JoystickSetVirtualButton(vjoy, 4, (st >> XRC_TC_BACK) & 1);
}
static void vjoy_attach(void) {
	if (vjoy) return;
	SDL_InitSubSystem(SDL_INIT_GAMECONTROLLER);
	vjoy_index = SDL_JoystickAttachVirtual(SDL_JOYSTICK_TYPE_GAMECONTROLLER, 6, 15, 0);
	if (vjoy_index < 0) {
		fprintf(stderr, "xrc-ios: touch: no virtual gamepad (%s)\n", SDL_GetError());
		return;
	}
	vjoy = SDL_JoystickOpen(vjoy_index);
	if (vjoy) vjoy_id = SDL_JoystickInstanceID(vjoy);
	fprintf(stderr, "xrc-ios: touch: virtual gamepad %s (device %d)\n",
		vjoy ? "attached" : "attach failed", vjoy_index);
}
static void vjoy_detach(void) {
	int a;
	if (!vjoy) return;
	for (a = 0; a < 6; a++) SDL_JoystickSetVirtualAxis(vjoy, a, 0);
	__atomic_store_n(&touch_st, 0, __ATOMIC_RELEASE);
	vjoy_write();
	SDL_JoystickClose(vjoy);
	SDL_JoystickDetachVirtual(vjoy_index);
	vjoy = 0; vjoy_index = -1; vjoy_id = -1;
}

/* shown or not (a real controller used: not; the screen touched:
 * again). The virtual pad is attached while they show. */
static void touch_show(int on) {
	unsigned st = __atomic_load_n(&touch_st, __ATOMIC_ACQUIRE);
	if (touch_off || !on == !(st >> 31)) return;
	if (on) {
		vjoy_attach();
		st = 1u << 31;
	} else {
		int k;
		for (k = 0; k < ntp; k++) tp[k].ctl = -1;
		ntp = 0;
		stk[0].on = stk[1].on = 0;
		vjoy_detach();
		st = 0;
	}
	__atomic_store_n(&touch_st, st, __ATOMIC_RELEASE);
	__atomic_add_fetch(&touch_ver, 1, __ATOMIC_RELEASE);
	if (on) vjoy_write();
}
static void touch_ensure_init(void) {
	const char *e;
	if (touch_ready) return;
	touch_ready = 1;
	e = getenv("XRC_TOUCH");
	touch_off = e && atoi(e) == 0;
	if (!touch_off) touch_show(1);
}
int xrc_ios_touch_enabled(void) {
	touch_ensure_init();
	return !touch_off;
}
/* a real controller did something (pump_events saw its event): hide.
 * Our own virtual pad's events carry its instance id -- not a hide. */
void xrc_ios_touch_hide(int instance_id) {
	touch_ensure_init();
	if (touch_off || instance_id == vjoy_id) return;
	touch_show(0);
}

/* ------------------------------------------------------------ the fingers */
/* the button at a picture position (a little larger than drawn), -1 none */
static int touch_hit(float x, float y) {
	XrcTouchCtl c[XRC_TC_N];
	int k;
	xrc_touch_layout(xrc_view_w, xrc_view_h, c);
	for (k = 0; k < XRC_TC_N; k++) {
		float dx = x - c[k].x, dy = y - c[k].y;
		if (dx * dx + dy * dy <= c[k].r * c[k].r * 1.35f * 1.35f) return k;
	}
	return -1;
}
/* stick k's knob to the finger at (x, y), kept inside its ring; its
 * axes set (-32767..32767, down positive) */
static void stick_move(int k, float x, float y) {
	float r = xrc_touch_stick_reach(xrc_view_h), dx = x - stk[k].cx, dy = y - stk[k].cy, d = __builtin_sqrtf(dx * dx + dy * dy);
	if (d > r && d > 0) { dx *= r / d; dy *= r / d; }
	stk[k].kx = stk[k].cx + dx; stk[k].ky = stk[k].cy + dy;
	if (vjoy) {
		SDL_JoystickSetVirtualAxis(vjoy, k * 2, (Sint16)(dx / r * 32767.0f));
		SDL_JoystickSetVirtualAxis(vjoy, k * 2 + 1, (Sint16)(dy / r * 32767.0f));
	}
}
static void stick_end(int k) {
	stk[k].on = 0;
	if (vjoy) {
		SDL_JoystickSetVirtualAxis(vjoy, k * 2, 0);
		SDL_JoystickSetVirtualAxis(vjoy, k * 2 + 1, 0);
	}
}
static void touch_publish(void) {
	unsigned st = 1u << 31;
	int k;
	for (k = 0; k < ntp; k++) if (tp[k].ctl >= 0 && tp[k].ctl < XRC_TC_N) st |= 1u << tp[k].ctl;
	__atomic_store_n(&touch_st, st, __ATOMIC_RELEASE);
	__atomic_add_fetch(&touch_ver, 1, __ATOMIC_RELEASE);
	vjoy_write();
}
static int tp_find(SDL_FingerID id) {
	int k;
	for (k = 0; k < ntp && tp[k].id != id; k++) {}
	return k < ntp ? k : -1;
}

/* an SDL finger event (vk_d3d9.c's pump_events forwards it): the
 * window is winw x winh points, the picture's part of it starts at
 * (vx0, vy0) and is vw x vh. 1: the touch controls took it. */
int xrc_ios_touch_finger(const void *evp, int winw, int winh, int vx0, int vy0, int vw, int vh) {
	const SDL_TouchFingerEvent *e = (const SDL_TouchFingerEvent *)evp;
	float px, py;
	int k;
	touch_ensure_init();
	if (touch_off || xrc_view_w <= 0 || xrc_view_h <= 0) return 0;
	if (winw <= 0 || winh <= 0) { winw = vw; winh = vh; }
	if (winw <= 0 || vw <= 0 || vh <= 0) return 1;
	px = (e->x * (float)winw - (float)vx0) * (float)xrc_view_w / (float)vw;
	py = (e->y * (float)winh - (float)vy0) * (float)xrc_view_h / (float)vh;
	if (e->type == SDL_FINGERDOWN) {
		int ctl = -1;
		touch_show(1);
		ctl = touch_hit(px, py);
		if (ctl < 0) { /* off the buttons: a stick, by the half it is on -- one finger each */
			int s = px >= xrc_view_w * 0.5f;
			if (!stk[s].on) {
				stk[s].cx = px; stk[s].cy = py;
				stick_move(s, px, py);
				stk[s].on = 1;
				ctl = TC_STICK + s;
			}
		}
		k = tp_find(e->fingerId);
		if (k < 0 && ntp < TP_N) { k = ntp++; tp[k].id = e->fingerId; }
		if (k >= 0) tp[k].ctl = ctl;
	} else if (e->type == SDL_FINGERMOTION) {
		k = tp_find(e->fingerId);
		if (k < 0) return 1;
		if (tp[k].ctl >= TC_STICK) stick_move(tp[k].ctl - TC_STICK, px, py);
		else { /* a finger sliding from one button to another presses that one */
			int b = touch_hit(px, py);
			if (b >= 0 || tp[k].ctl >= 0) tp[k].ctl = b;
		}
	} else if (e->type == SDL_FINGERUP) {
		k = tp_find(e->fingerId);
		if (k < 0) return 1;
		if (tp[k].ctl >= TC_STICK) stick_end(tp[k].ctl - TC_STICK);
		tp[k] = tp[--ntp];
	} else return 1;
	touch_publish();
	return 1;
}
