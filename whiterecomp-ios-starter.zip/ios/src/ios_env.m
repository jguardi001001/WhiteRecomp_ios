/* ios_env.m -- the iOS platform shim for the WhiteRecomp game, the counterpart
 * of runtime/xrc_android.c's android_main setup (which does the same job on
 * Android: find the game, set XRC_* in the environment, then start the game).
 *
 * This file has no main() of its own. A constructor runs before SDL_main (the
 * game's main(), renamed at compile time -- see build_ios.sh), and prepares
 * everything the runtime reads from the environment / its .cfg:
 *
 *   XRC_GAME_DIR   <Documents>/FINAL FANTASY XIII   (copied in by the player
 *                                                    via the Files app)
 *   XRC_EXE        .../white_data/prog/win/bin/ffxiiiimg.exe
 *   XRC_CDRIVE     <Documents>/cdrive               (the game's saves)
 *   XRC_SDL_LIB    <app>/Frameworks/SDL2.framework/SDL2
 *   XRC_VK_LIB     <app>/Frameworks/MoltenVK.framework/MoltenVK
 *   XRC_NO_STEAM=1, XRC_MOVIE_NO_CONVERT=1          (as on Android: no Steam,
 *                                                    movies pre-converted
 *                                                    on a PC travel along)
 *   XRC_GAME_ARGS  "-Shadow=1024 -MSAA=4 -Width=2868 -Height=1320"
 *                                                    (the same arguments are
 *                                                    ALSO passed as real argv
 *                                                    by ios_main.m, the way the
 *                                                    desktop launcher invokes
 *                                                    the runtime; the env copy
 *                                                    only reaches the game's
 *                                                    GetCommandLineA string)
 *                                                    (the Android phone preset,
 *                                                    shadows raised to 1024 and
 *                                                    MSAA restored at the
 *                                                    player's request: with
 *                                                    MSAA off, the renderer
 *                                                    turns the game's
 *                                                    alpha-to-coverage hair /
 *                                                    eyelashes into a hard
 *                                                    alpha test at 0.5 and the
 *                                                    lashes are discarded;
 *                                                    -Width/-Height raise the
 *                                                    game's internal render
 *                                                    from 1280x720 to
 *                                                    2868x1320, the iPhone 16
 *                                                    Pro Max panel's own pixel
 *                                                    count (a 3840x2160 build
 *                                                    was tried first, at the
 *                                                    player's request))
 *   XRC_VK_PIPE_THREADS=2
 *
 * Values already in the environment win (setenv with overwrite=0), matching
 * load_cfg's rule in xrc_rt.c, so a WhiteRecomp.cfg the player drops into
 * Documents can override them.
 *
 * stderr is redirected to <Documents>/ff13.log (the game prints its whole
 * log there; on iOS there is no console to watch), as Android does.
 *
 * If the game folder is not there yet, the shim does NOT block: the game
 * will fail to load its exe and exit, and the log says what to copy. A
 * friendlier "waiting" screen like Android's needs the touch overlay's
 * renderer, which only exists once the game starts -- see ../README.md.
 */
#import <Foundation/Foundation.h>

#include <fcntl.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <sys/stat.h>
#include <unistd.h>

static void set_if_absent(const char *name, NSString *value) {
    if (!value) return;
    setenv(name, [value fileSystemRepresentation], 0);
}

/* Stage markers that cannot be lost: written with raw write() (no stdio
 * buffer to die in a crash) AND via NSLog (so they also show on the
 * console / LiveContainer log screen the player actually watches). */
static char g_logpath[1024];
static void mark(const char *msg) {
    NSLog(@"xrc-ios: %s", msg);
    if (!g_logpath[0]) return;
    int fd = open(g_logpath, O_WRONLY | O_CREAT | O_APPEND, 0644);
    if (fd < 0) return;
    char buf[1200];
    int n = snprintf(buf, sizeof buf, "xrc-ios: %s\n", msg);
    if (n > 0) (void)!write(fd, buf, (size_t)n);
    close(fd);
}

__attribute__((constructor)) static void xrc_ios_setup(void) {
    @autoreleasepool {
        NSString *bundle = [[NSBundle mainBundle] bundlePath];
        NSString *docs = [NSSearchPathForDirectoriesInDomains(
            NSDocumentDirectory, NSUserDomainMask, YES) firstObject];
        if (!bundle || !docs) return;

        /* the log first, so even a failed start leaves a readable trace */
        NSString *log = [docs stringByAppendingPathComponent:@"ff13.log"];
        snprintf(g_logpath, sizeof g_logpath, "%s", [log fileSystemRepresentation]);
        mark("shim constructor");
        freopen([log fileSystemRepresentation], "a", stderr);
        setvbuf(stderr, NULL, _IONBF, 0); /* a crash must not eat the log */
        fprintf(stderr, "xrc: ios: app %s, documents %s\n",
                [bundle UTF8String], [docs UTF8String]);

        NSString *cdrive = [docs stringByAppendingPathComponent:@"cdrive"];
        [[NSFileManager defaultManager] createDirectoryAtPath:cdrive
                                  withIntermediateDirectories:YES
                                                   attributes:nil
                                                        error:nil];

        NSString *game = [docs stringByAppendingPathComponent:@"FINAL FANTASY XIII"];
        NSString *exe = [game stringByAppendingPathComponent:
                         @"white_data/prog/win/bin/ffxiiiimg.exe"];
        if (![[NSFileManager defaultManager] fileExistsAtPath:exe]) {
            mark("game exe NOT found at the expected path");
            fprintf(stderr,
                    "xrc: ios: game not found: copy the 'FINAL FANTASY XIII' folder "
                    "(from a Windows Steam install) into this app's Documents folder "
                    "with the Files app; expected the exe at %s\n",
                    [exe UTF8String]);
        } else {
            mark("game exe found");
        }

        set_if_absent("XRC_GAME_DIR", game);
        set_if_absent("XRC_EXE", exe);
        set_if_absent("XRC_CDRIVE", cdrive);
        set_if_absent("XRC_SDL_LIB",
                      [bundle stringByAppendingPathComponent:
                       @"Frameworks/SDL2.framework/SDL2"]);
        set_if_absent("XRC_VK_LIB",
                      [bundle stringByAppendingPathComponent:
                       @"Frameworks/MoltenVK.framework/MoltenVK"]);
        set_if_absent("XRC_STRETCH", @"1"); /* the picture fills the screen (the launcher's Window Scaling: Stretch) */
        set_if_absent("XRC_MOVIES", @"bink"); /* v0.0.13: the game's own bink2w32.dll, translated -- the .wmp cutscenes play directly, no conversion (anything else keeps the MP4 player) */
        set_if_absent("XRC_NO_STEAM", @"1");
        set_if_absent("XRC_MOVIE_NO_CONVERT", @"1");
        set_if_absent("XRC_GAME_ARGS", @"-Shadow=1024 -MSAA=4");
        set_if_absent("XRC_VK_PIPE_THREADS", @"2");
        set_if_absent("HOME", docs);
        chdir([docs fileSystemRepresentation]);
        mark("shim done");
    }
}
