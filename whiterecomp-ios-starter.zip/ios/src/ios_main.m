/* ios_main.m -- the iOS entry point.
 *
 * Lifecycle (third design, the one that launches):
 * iOS 26+ refuses to launch apps built with the current SDK that have
 * not adopted the UIScene life cycle (Apple TN3187): UIApplicationMain
 * starts, but no app-delegate callback ever fires -- the log simply
 * stops after "main entered". Both earlier entries (SDL_UIKitRunApp,
 * then our own delegate calling SDL_main from didFinishLaunching) died
 * at exactly that line, in LiveContainer and standalone alike.
 *
 * So: the app delegate only reports readiness and vends a scene
 * configuration; the SCENE delegate starts the game. In willConnect it
 * puts a placeholder window on the scene, then starts SDL_main from
 * the main queue. SDL_main blocks that thread for the game's life,
 * with SDL's event pump keeping UIKit events flowing
 * (SDL_iPhoneSetEventPump(SDL_TRUE)).
 *
 * Black-screen fix, second attempt: the game renders into SDL's own
 * window, which SDL creates the pre-scene way. Enumerating
 * UIApplication.windows / scene.windows never finds it -- a window
 * with no scene is invisible to both lists -- so the first adoption
 * attempt ("adopted SDL window") never fired and the black
 * placeholder stayed on screen while the title music played. Now the
 * delegate asks SDL itself: SDL_GetWindowWMInfo returns the UIWindow
 * behind SDL's window directly. It is then moved onto our scene, made
 * key and visible, and the placeholder hides. Attempts repeat on a
 * timer because SDL creates the window a little after SDL_main
 * starts; the game's event pump keeps the main runloop turning, so
 * the delayed calls do fire.
 *
 * The game's main() is runtime/xrc_rt.c compiled with -Dmain=SDL_main
 * (see build_ios.sh). SDL_MAIN_HANDLED is defined because we provide
 * main() and the delegates ourselves; SDL_SetMainReady() tells SDL
 * exactly that, so SDL_Init does not go looking for SDL's delegate.
 */
#import <UIKit/UIKit.h>
#import <QuartzCore/QuartzCore.h>
#import <GameController/GameController.h>

#define SDL_MAIN_HANDLED 1
#include <SDL_main.h>
#include <SDL_system.h>
#include <SDL_video.h>
#include <SDL_syswm.h>
#include <SDL_joystick.h>

#include <stdio.h>
#include <string.h>

extern int SDL_main(int argc, char *argv[]);

static int g_argc;
static char **g_argv;
static UIWindowScene *g_scene;
static UIWindow *g_sdlWindow;
static SDL_Window *g_sdlw;
static int g_attach_tries;
static BOOL g_adopted;
static BOOL g_chain_running;

/* What iOS itself hands this app, asked directly through Apple's
 * GameController framework, bypassing SDL entirely: if a pad is
 * missing here too, iOS is not offering it to the app (the pad's
 * mode); if it is here but absent from the SDL census in
 * xrc_ios_touch.c, the blindness is in our SDL build. Logged at
 * scene connect and on every controller (dis)connect. */
static void xrc_log_gc_controllers(const char *when) {
    NSArray<GCController *> *cs = [GCController controllers];
    fprintf(stderr, "xrc-ios: GCController (%s): %lu controller(s)\n",
            when, (unsigned long)[cs count]);
    for (GCController *c in cs) {
        fprintf(stderr, "xrc-ios: GCController: \"%s\" category %s extended %s\n",
                [[c vendorName] UTF8String] ?: "?",
                [[c productCategory] UTF8String] ?: "?",
                [c extendedGamepad] ? "yes" : "no");
    }
}

@interface XRCAppDelegate : NSObject <UIApplicationDelegate>
@property(nonatomic, strong) UIWindow *window;
@end

@interface XRCSceneDelegate : NSObject <UIWindowSceneDelegate>
@property(nonatomic, strong) UIWindow *window;
@end

@implementation XRCAppDelegate

- (BOOL)application:(UIApplication *)application
    didFinishLaunchingWithOptions:(NSDictionary *)launchOptions {
    fprintf(stderr, "xrc-ios: didFinishLaunching (waiting for a scene)\n");
    return YES;
}

- (UISceneConfiguration *)application:(UIApplication *)application
    configurationForConnectingSceneSession:
        (UISceneSession *)connectingSceneSession
                                   options:(UISceneConnectionOptions *)options {
    fprintf(stderr, "xrc-ios: configurationForConnectingSceneSession\n");
    UISceneConfiguration *config = [[UISceneConfiguration alloc]
        initWithName:@"Default Configuration"
         sessionRole:connectingSceneSession.role];
    config.delegateClass = [XRCSceneDelegate class];
    return config;
}

@end

@implementation XRCSceneDelegate

/* SDL created its window sceneless, so its Metal layer came up at
 * contents scale 1.0 -- a 440x956 drawable on a 1320x2868 panel. Put
 * the layer (and the view, so SDL's own resizes keep it) at the
 * screen's native scale; the renderer notices the new drawable size
 * and rebuilds the swapchain at full resolution. */
- (UIView *)xrc_metalViewIn:(UIView *)view layer:(CAMetalLayer **)out {
    if ([view.layer isKindOfClass:[CAMetalLayer class]]) {
        *out = (CAMetalLayer *)view.layer;
        return view;
    }
    for (UIView *sub in view.subviews) {
        UIView *found = [self xrc_metalViewIn:sub layer:out];
        if (found) return found;
    }
    return nil;
}

- (void)xrc_nativeScale:(UIWindow *)window {
    CGFloat scale = g_scene ? g_scene.screen.scale
                            : [UIScreen mainScreen].scale;
    UIView *root = window.rootViewController.view;
    CAMetalLayer *layer = nil;
    UIView *metalView = root ? [self xrc_metalViewIn:root layer:&layer] : nil;
    if (!layer || scale <= 1.0) return;
    CGSize want = CGSizeMake(root.bounds.size.width * scale,
                             root.bounds.size.height * scale);
    if (layer.contentsScale == scale &&
        CGSizeEqualToSize(layer.drawableSize, want)) return;
    root.contentScaleFactor = scale;
    if (metalView) metalView.contentScaleFactor = scale;
    layer.contentsScale = scale;
    layer.drawableSize = want;
    fprintf(stderr, "xrc-ios: drawable at native scale %.0f (%dx%d)\n",
            (double)scale, (int)want.width, (int)want.height);
}

/* Ask SDL for the UIWindow behind its window. Works even though the
 * window is attached to no scene and appears in no window list. */
- (UIWindow *)xrc_SDLWindow {
    for (Uint32 id = 1; id <= 16; id++) {
        SDL_Window *w = SDL_GetWindowFromID(id);
        if (w == NULL) continue;
        SDL_SysWMinfo info;
        SDL_VERSION(&info.version);
        if (SDL_GetWindowWMInfo(w, &info) &&
            info.subsystem == SDL_SYSWM_UIKIT) {
            g_sdlw = w;
            return info.info.uikit.window;
        }
    }
    return nil;
}

/* Move SDL's window onto our scene and make it the visible one.
 * Returns YES once done. */
- (BOOL)xrc_adoptSDLWindow {
    if (g_adopted) return YES;
    UIWindow *sdlWindow = [self xrc_SDLWindow];
    if (sdlWindow == nil) {
        /* fallback: any enumerated window that is not the placeholder */
        NSMutableArray<UIWindow *> *all = [NSMutableArray array];
        if (g_scene) [all addObjectsFromArray:g_scene.windows];
        [all addObjectsFromArray:[UIApplication sharedApplication].windows];
        for (UIWindow *w in all) {
            if (w != self.window && w.rootViewController != nil) {
                sdlWindow = w;
                break;
            }
        }
    }
    if (sdlWindow == nil) return NO;
    fprintf(stderr, "xrc-ios: found SDL window %p (scene %p, hidden %d)\n",
            (void *)sdlWindow, (void *)sdlWindow.windowScene,
            (int)sdlWindow.hidden);
    sdlWindow.windowScene = g_scene;
    sdlWindow.hidden = NO;
    [sdlWindow makeKeyAndVisible];
    self.window.hidden = YES;
    g_sdlWindow = sdlWindow;
    [self xrc_nativeScale:sdlWindow];
    /* the Metal view may not exist yet at adoption time; look again
     * shortly (a no-op once the scale is right) */
    [self performSelector:@selector(xrc_scaleRetry)
               withObject:nil
               afterDelay:1.0];
    [self performSelector:@selector(xrc_scaleRetry)
               withObject:nil
               afterDelay:3.0];
    /* SDL's own window flags never learn of the adoption above (its app
     * delegate is not running): in SDL's books the window stays HIDDEN /
     * MINIMIZED, and v0.0.12's renderer refuses to present into a hidden
     * window ("the window minimized: frames not presented"). Tell SDL
     * directly that its window is shown. (The runtime's plat_hidden is
     * also patched off on iOS; this keeps SDL's state honest regardless.) */
    if (g_sdlw) {
        Uint32 before = SDL_GetWindowFlags(g_sdlw);
        SDL_ShowWindow(g_sdlw);
        SDL_RestoreWindow(g_sdlw);
        fprintf(stderr, "xrc-ios: SDL window flags %08x -> %08x after show/restore\n",
                before, SDL_GetWindowFlags(g_sdlw));
    }
    g_adopted = YES;
    fprintf(stderr, "xrc-ios: adopted SDL window onto the scene\n");
    return YES;
}

- (void)xrc_scaleRetry {
    if (g_sdlWindow) [self xrc_nativeScale:g_sdlWindow];
}

- (void)xrc_attachAttempt {
    g_chain_running = NO;
    if ([self xrc_adoptSDLWindow]) return;
    if (++g_attach_tries <= 80) {
        g_chain_running = YES;
        [self performSelector:@selector(xrc_attachAttempt)
                   withObject:nil
                   afterDelay:0.25];
    } else {
        fprintf(stderr, "xrc-ios: WARNING SDL window never appeared\n");
    }
}

- (void)xrc_kickAttach {
    if (!g_adopted && !g_chain_running) {
        g_chain_running = YES;
        [self performSelector:@selector(xrc_attachAttempt)
                   withObject:nil
                   afterDelay:0.25];
    }
}

- (void)scene:(UIScene *)scene
    willConnectToSession:(UISceneSession *)session
                 options:(UISceneConnectionOptions *)connectionOptions {
    fprintf(stderr, "xrc-ios: scene willConnect\n");
    if (![scene isKindOfClass:[UIWindowScene class]]) return;
    g_scene = (UIWindowScene *)scene;
    [[NSNotificationCenter defaultCenter]
        addObserver:self
           selector:@selector(xrc_controllerChanged:)
               name:GCControllerDidConnectNotification
             object:nil];
    [[NSNotificationCenter defaultCenter]
        addObserver:self
           selector:@selector(xrc_controllerChanged:)
               name:GCControllerDidDisconnectNotification
             object:nil];
    [GCController startWirelessControllerDiscoveryWithCompletionHandler:nil];
    xrc_log_gc_controllers("scene connect");
    [self performSelector:@selector(xrc_gcPoll)
               withObject:nil
               afterDelay:5.0];
    self.window = [[UIWindow alloc] initWithWindowScene:g_scene];
    self.window.backgroundColor = [UIColor blackColor];
    [self.window makeKeyAndVisible];

    [self xrc_kickAttach];

    /* Start the game from a RUNLOOP TIMER callout, the way SDL's own
     * app delegate does (performSelector:afterDelay:0 -> postFinishLaunch),
     * NOT from a dispatch_async(main) block.
     *
     * Why it matters: SDL_main never returns, so the whole game lives
     * inside whatever callout started it. Inside a main-queue block the
     * main queue is "being drained" for the game's entire life, and the
     * nested CFRunLoopRunInMode in SDL's event pump cannot run further
     * main-queue blocks. GameController (and SDL's MFi joystick driver
     * on top of it) delivers its controller list and connect
     * notifications as main-queue blocks, so they never ran: no
     * controller ever appeared, over USB-C or Bluetooth, while PadProbe
     * (which stays on the normal runloop) saw the pad in ~1 s. From a
     * timer callout the main queue is free, and the pump services it. */
    [self performSelector:@selector(xrc_startGame)
               withObject:nil
               afterDelay:0.0];
}

- (void)xrc_startGame {
    fprintf(stderr, "xrc-ios: calling SDL_main (from a runloop timer)\n");
    SDL_SetMainReady();
    SDL_iPhoneSetEventPump(SDL_TRUE);
    int rc = SDL_main(g_argc, g_argv);
    SDL_iPhoneSetEventPump(SDL_FALSE);
    fprintf(stderr, "xrc-ios: SDL_main returned %d\n", rc);
}

- (void)xrc_controllerChanged:(NSNotification *)note {
    xrc_log_gc_controllers("changed");
}

/* The scene-connect probe alone can be dodged by plug order (pad
 * clamped on after launch, notification lost in the shuffle), so
 * also poll: every 5 s for the first minute, whatever the state.
 *
 * PadProbe (a bare UIKit+GameController app, same signing) sees the
 * pad fine, so the blindness is inside this process. Prime suspect:
 * SDL_main owns the main thread and pumps UIKit events SDL's way,
 * while GameController maintains its device list through the main
 * runloop -- which that pump may never service in the mode the
 * framework needs, so the list stays empty however often it is
 * asked. The poll therefore spins the runloop properly for a beat
 * before asking (the scene-connect line stays a pure query, as the
 * before/after witness), and cross-checks what SDL itself sees. */
static int g_gc_polls;
- (void)xrc_gcPoll {
    CFRunLoopRunInMode(kCFRunLoopDefaultMode, 0.05, false);
    xrc_log_gc_controllers("poll");
    fprintf(stderr, "xrc-ios: SDL joysticks at poll: %d\n",
            SDL_NumJoysticks());
    if (++g_gc_polls < 12)
        [self performSelector:@selector(xrc_gcPoll)
                   withObject:nil
                   afterDelay:5.0];
}

- (void)sceneDidBecomeActive:(UIScene *)scene {
    fprintf(stderr, "xrc-ios: scene did become active\n");
    xrc_log_gc_controllers("became active");
    [self xrc_kickAttach];
    if (g_sdlWindow) [self xrc_nativeScale:g_sdlWindow];
}

@end

int main(int argc, char *argv[]) {
    /* unbuffered from here on: a crash must not eat the log */
    setvbuf(stderr, NULL, _IONBF, 0);
    fprintf(stderr, "xrc-ios: main entered, calling UIApplicationMain\n");
    /* Invoke the runtime the way the desktop launcher does: argv[1] is the
     * game exe, argv[2..] are the game's own arguments (xrc_rt.c takes
     * everything after the exe path as the game's arguments). The process
     * argv on iOS is just the program name, which left the game with NO
     * arguments -- it ran on its built-in defaults (1280x720, multisample
     * 0) whatever the settings said. The exe path is the shim's XRC_EXE. */
    const char *exe = getenv("XRC_EXE");
    if (exe) {
        static char *gargv[8];
        int n = 0;
        gargv[n++] = (char *)"WhiteRecomp";
        gargv[n++] = (char *)exe;
        gargv[n++] = (char *)"-Shadow=1024";
        gargv[n++] = (char *)"-MSAA=4";
        /* No -Width/-Height: on the old runtime they produced a black
         * screen with a healthy log (bisected 2026-11-22, the args, not
         * MSAA), and the v0.0.12 tests with them stayed black too. The
         * game renders at its 1280x720 internal size and the runtime
         * presents it at the panel's native 2868x1320. Raising the
         * internal resolution is a separate investigation. */
        gargv[n] = NULL;
        g_argc = n;
        g_argv = gargv;
        fprintf(stderr, "xrc-ios: game argv: -Shadow=1024 -MSAA=4\n");
    } else {
        g_argc = argc;
        g_argv = argv;
    }
    @autoreleasepool {
        return UIApplicationMain(argc, argv, nil,
                                 NSStringFromClass([XRCAppDelegate class]));
    }
}
