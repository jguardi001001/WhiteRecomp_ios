#!/bin/sh
# fetch_deps.sh -- get the three iOS dependencies build_ios.sh needs, into
# ios/deps/:
#   SDL2.xcframework       built from the official SDL source release with
#                          SDL's own "xcFramework-iOS" Xcode scheme. (The
#                          SDL .dmg download is a macOS-only framework --
#                          there is no iOS binary download. v1 of this
#                          script wrongly assumed one; fixed.)
#   MoltenVK.xcframework   from the official MoltenVK-iOS.tar release
#                          (Vulkan on Metal; the macOS tar contains only
#                          macOS slices -- the iOS tar is separate).
#   ffmpeg/                static FFmpeg for iphoneos-arm64, built from
#                          source (no official iOS binary exists). LGPL
#                          configuration like the bundled desktop one:
#                          libavformat/libavcodec/libswresample/libavutil.
#
# Run on a Mac with Xcode. Versions are pinned; bump them deliberately.
set -eu
cd "$(dirname "$0")"
DEPS="$PWD/deps"
mkdir -p "$DEPS"
WORK="$(mktemp -d)"
trap 'rm -rf "$WORK" 2>/dev/null || true' EXIT

SDL_VER=2.32.10
MVK_VER=1.4.1
FF_VER=7.1.1

# --- SDL2: build the XCFramework from the official source -----------------
if [ ! -d "$DEPS/SDL2.xcframework" ]; then
    echo "== SDL2 $SDL_VER: building SDL2.xcframework (a few minutes) =="
    curl -L -o "$WORK/sdl.tar.gz" \
        "https://github.com/libsdl-org/SDL/releases/download/release-$SDL_VER/SDL2-$SDL_VER.tar.gz"
    tar -xzf "$WORK/sdl.tar.gz" -C "$WORK"
    # SDL 2.32's project still targets iOS 12.1/9.0, which current Xcode
    # (deployment-target floor 15.0) refuses. Retarget the project file
    # itself -- a command-line override would not reach the scheme's inner
    # `xcodebuild archive` invocations.
    PBX="$WORK/SDL2-$SDL_VER/Xcode/SDL/SDL.xcodeproj/project.pbxproj"
    sed -i '' -E \
        -e 's/IPHONEOS_DEPLOYMENT_TARGET = [0-9.]+/IPHONEOS_DEPLOYMENT_TARGET = 17.0/g' \
        -e 's/TVOS_DEPLOYMENT_TARGET = [0-9.]+/TVOS_DEPLOYMENT_TARGET = 17.0/g' \
        -e 's/MACOSX_DEPLOYMENT_TARGET = [0-9.]+/MACOSX_DEPLOYMENT_TARGET = 11.0/g' \
        "$PBX"
    # SDL's own scheme: archives Framework-iOS for device + simulator and
    # assembles Products/SDL2.xcframework beside the project.
    xcodebuild -project "$WORK/SDL2-$SDL_VER/Xcode/SDL/SDL.xcodeproj" \
        -scheme xcFramework-iOS -configuration Release -quiet \
        IPHONEOS_DEPLOYMENT_TARGET=17.0
    XCF="$(find "$WORK/SDL2-$SDL_VER" -name SDL2.xcframework -type d | head -n 1)"
    [ -n "$XCF" ] || { echo "xcodebuild finished but no SDL2.xcframework was produced"; exit 1; }
    cp -R "$XCF" "$DEPS/"
fi

# --- MoltenVK (iOS package) ------------------------------------------------
if [ ! -d "$DEPS/MoltenVK.xcframework" ]; then
    echo "== MoltenVK $MVK_VER (iOS) =="
    curl -L -o "$WORK/mvk.tar" \
        "https://github.com/KhronosGroup/MoltenVK/releases/download/v$MVK_VER/MoltenVK-iOS.tar"
    tar -xf "$WORK/mvk.tar" -C "$WORK"
    cp -R "$WORK/MoltenVK/MoltenVK/dynamic/MoltenVK.xcframework" "$DEPS/"
fi

# --- FFmpeg (build for iphoneos) ------------------------------------------
if [ ! -f "$DEPS/ffmpeg/lib/libavcodec.a" ]; then
    echo "== FFmpeg $FF_VER (iphoneos arm64) =="
    curl -L -o "$WORK/ffmpeg.tar.xz" "https://ffmpeg.org/releases/ffmpeg-$FF_VER.tar.xz"
    tar -xf "$WORK/ffmpeg.tar.xz" -C "$WORK"
    SDK="$(xcrun --sdk iphoneos --show-sdk-path)"
    cd "$WORK/ffmpeg-$FF_VER"
    ./configure \
        --prefix="$DEPS/ffmpeg" \
        --target-os=darwin --arch=arm64 --cpu=armv8 --enable-cross-compile \
        --cc="xcrun -sdk iphoneos clang" \
        --sysroot="$SDK" \
        --extra-cflags="-miphoneos-version-min=17.0" \
        --extra-ldflags="-miphoneos-version-min=17.0" \
        --enable-static --disable-shared \
        --disable-avdevice \
        --disable-programs --disable-doc --disable-network \
        --disable-gpl --disable-nonfree \
        --disable-decoders --enable-decoder=h264,aac,mp3,pcm_s16le,pcm_s24le \
        --disable-demuxers --enable-demuxer=mov,mp4,m4a,wav,mp3 \
        --disable-parsers --enable-parser=h264,aac,mpegaudio \
        --disable-bsfs --enable-bsf=aac_adtstoasc,h264_mp4toannexb \
        --enable-protocol=file \
        --disable-filters --enable-filter=aresample,anull,copy,format,aformat
    make -j"$(sysctl -n hw.ncpu)"
    make install
fi

echo "deps ready in $DEPS:"
ls "$DEPS"
ls "$DEPS/SDL2.xcframework" "$DEPS/MoltenVK.xcframework"
ls "$DEPS/ffmpeg/lib"
