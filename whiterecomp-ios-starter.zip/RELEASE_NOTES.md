# WhiteRecomp iOS — First Release

<a href="https://ko-fi.com/joshua27658"><img src="https://ko-fi.com/img/githubbutton_sm.svg" width="340" alt="Support this project on Ko-fi"></a>

**Tips & donations:** https://ko-fi.com/joshua27658

**FINAL FANTASY XIII, playable on iPhone.** This is the first release of the
iOS port of [WhiteRecomp](https://github.com/ps4star/WhiteRecomp) by ps4star,
based on upstream **v0.0.13**.

Tested on iPhone 16 Pro Max (A18 Pro), installed with SideStore.

## Highlights

- 🎮 **The full game on your phone** — the Steam PC version of FFXIII,
  recompiled by WhiteRecomp and running natively on iOS
- 🎬 **Cutscenes just play** — upstream v0.0.13 translates the game's own
  `bink2w32.dll`, so movies play straight from the original `.wmp` files,
  with sound. No conversion, no Wine, no 40 GB of MP4s
- ✨ **Hair and eyelashes fixed** — upstream's v0.0.12 alpha-to-coverage
  fix, live with MSAA 4×
- 🖥️ **60 fps at native panel resolution** (2868×1320 presentation,
  1280×720 internal render upscaled), 1024×1024 shadows, full-resolution
  effects
- 👆 **Touch controls** — an on-screen gamepad (dual sticks + buttons)
  implemented as an SDL virtual controller
- 📱 iOS-native shell: UIScene lifecycle for current iOS, the game's
  window adopted onto the scene at full native scale, app icon included

## What you need

- A Mac with Xcode to build (Apple Silicon used here)
- An iPhone/iPad on iOS 17+, and SideStore / AltStore / LiveContainer to
  install the unsigned IPA
- **Your own Steam copy of FINAL FANTASY XIII** (Windows version,
  AppID 292120) — no game data is included

## Install

1. Build: `sh setup_on_mac.sh`, then `sh ios/fetch_deps.sh` (first time),
   then `sh ios/build_ios.sh` → `WhiteRecomp.ipa`
2. Install the IPA with SideStore
3. Copy your **`FINAL FANTASY XIII`** folder into the app's Documents
   (Files app or Finder)
4. Launch and play — a log is kept at `Documents/ff13.log`

⚠️ Reinstalling the app wipes its data container — copy the game folder in
again afterwards. A signature refresh in place keeps your data.

Full instructions are in the README.

## Known issues

- **Physical controllers work** (GameSir X5 Lite over USB-C tested) —
  fixed after the first release: the game now starts from a runloop
  timer callout instead of a main-queue block, which had starved
  GameController's controller delivery for the game's whole run.
- **Don't background the app mid-game** — iOS kills the Vulkan device when
  the app leaves the foreground (`VK_ERROR_DEVICE_LOST`).
- **Internal resolution is fixed at 1280×720** — forcing it higher via
  `-Width`/`-Height` currently gives a black screen (game logic and sound
  unaffected). Presentation is at native resolution regardless.
- **Free signing strips the increased-memory entitlements**, so the port
  runs within standard per-app memory limits.

## Thanks

Huge thanks to **ps4star** for WhiteRecomp and its rapid releases; to
**Square Enix** for the game; to the **SDL**, **MoltenVK**, and **FFmpeg**
projects; to **SideStore** and **LiveContainer**; to the author of the
Steam Community graphics guide; to **Claude** for the UIScene fix that got
the app launching on current iOS; and to everyone who tested builds and
sent logs. Full credits in the README.

If you'd like to support this hobby project, tips are welcome on Ko-fi:
https://ko-fi.com/joshua27658

---

*Unofficial fan project. Not affiliated with Square Enix or the WhiteRecomp
project. You must own the game — no game data is distributed.*
