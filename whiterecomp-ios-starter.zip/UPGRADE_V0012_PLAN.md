# WhiteRecomp iOS port — upgrade plan: v0.0.9 bundle → v0.0.12

Status: audited and prepared 2026-11-22. The v0.0.12 sources are already
downloaded and extracted in this workspace (`v0012/bundle/`, 3,159 files,
795.6 MB) and every check below was run against them. The current v0.0.9
build (with the backported hair fix) stays the working fallback until the
new build is verified on the phone.

## What the upgrade buys

- **Hair/eyelashes fixed upstream** (alpha-to-coverage the right way
  round) — our `patch_a2c_fix.py` backport becomes unnecessary.
- **Movies done properly**: per-scene MP4s (one .wmp can hold 8
  cutscenes) played via the new runtime's stream mapping, and the
  v0.0.12 Mac launcher can *create* those MP4s on macOS through Wine —
  no Windows PC needed any more.
- **~20% CPU** from the translator (static de-virtualization) plus more
  in-battle override routines — headroom we want at 2868×1320 internal.
- Per-thread exception-handler chains, Xbox-pad presentation fixes
  (Windows-side), Android controller merging (not iOS, but the SDL
  gamepad backend our virtual pad uses is unchanged).

## Audit results (all verified against the real v0.0.12 bundle)

- Bundle format unchanged: our `tools/extract_bundle.py` extracts it
  as-is. Mac launcher zip: 158,130,095 B, SHA-256
  `e942dae7ee3abae98e25655938b046ba22de142e66dc20921f4621ff2b25cc14`.
- `patch_markers.py` applies cleanly to v0.0.12 `xrc_rt.c`.
- `patch_touch.py` applies cleanly to v0.0.12 `vk_d3d9.c` +
  `xrc_android.h`, and the patched renderer compiles (Linux gcc check).
- `patch_a2c_fix.py` correctly reports "already applied" — retire it.
- Runtime conventions our iOS layer depends on are unchanged:
  `xrc_argv = argv + 2` after the exe path, `XRC_EXE` fallback,
  `load_cfg()` semantics, `XRC_STRETCH`. `ios_main.m`, `ios_env.m`,
  `xrc_ios_touch.c`, `Info.plist`, `WhiteRecomp.cfg` carry over as-is.
- Compile-unit counts are the same (gen/src 202, overrides 6, match 1):
  the bigger bundle is bigger files, not more files. Full-rebuild time
  grows somewhat, not wildly.
- `hle_dinput.c`'s SDL gamepad backend is intact (same SDL reference
  count) — the touch-as-virtual-controller design survives.
- `host_movie_convert.c`'s Windows parts stay behind `#ifdef _WIN32`;
  the new stream-table functions are cross-platform C.

## The one real problem: the new Cocoa window branch

v0.0.12 gives macOS its own window layer: in `vk_d3d9.c`, an
`#elif defined(__APPLE__)` branch creates an AppKit NSWindow via the new
`xrc_cocoa.c` (VK_EXT_metal_surface) instead of an SDL window. **iOS is
`__APPLE__` too**, so an unpatched iOS build would take that branch — and
AppKit doesn't exist on iOS. It would also orphan our whole window
design (SDL UIKit window adopted onto the UIScene by `ios_main.m`).

Prepared solution (written and verified):
`tools/patch_ios_window.py` steers the two Cocoa-selecting conditions
(the window branch and `plat_unusable`'s alert branch) with
`&& !defined(XRC_IOS)`; the iOS build compiles the runtime with
`-DXRC_IOS` and skips `xrc_cocoa.c` in the runtime glob. The SDL
`plat_window` fallback (line ~549, `SDL_CreateWindow_` + Vulkan surface)
is intact in v0.0.12, and the fully patched file compile-checks clean.

## Steps

1. **Snapshot the fallback.** Zip the current starter kit as
   `whiterecomp-ios-starter-v009.zip` before touching anything. The
   v0.0.9 launcher stays in `original/`; the 0.0.9 state is always
   reproducible.
2. **Swap the source bundle.** `setup_on_mac.sh`: point at the v0.0.12
   Mac zip (URL + SHA-256 above); extraction via the existing extractor
   into `src/bundle/`. Same for the extraction fallback inside
   `build_ios.sh` (it names the v0.0.9 app path).
3. **build_ios.sh changes** (small, all prepared or mechanical):
   - drop the `patch_a2c_fix.py` invocation; add
     `patch_ios_window.py "$SRC/runtime/vk_d3d9.c"` after patch_touch;
   - add `-DXRC_IOS` to `compile_rt`'s defines;
   - runtime glob skip list: add `xrc_cocoa.c` (with `ref_*`,
     `xrc_android.c`);
   - flags stamp: `A2CFIX=1` → `V0012=1` (forces the full rebuild).
   - Watch item: `xrc_ir_glue.c` (new, LLVM-backend glue) will be
     picked up by the glob; it is self-contained C with static asserts
     and should compile/link inertly for the C backend. If the link
     disagrees, add it to the skip list.
4. **Build on the Mac** (`sh ios/build_ios.sh`), install via SideStore,
   re-copy the game folder if the container changed (it usually does).
5. **First-run checklist** (ff13.log receipts + eyes):
   - stage markers all fire; runtime argv line shows
     `-Shadow=1024 -MSAA=4 -Width=2868 -Height=1320`;
   - log's window line is the SDL one (`(SDL 2.32.10, uikit)`), *not*
     anything Cocoa — proves the steering worked;
   - swapchain at native 2868×1320 after scene adoption; ~60 fps;
   - hair/eyelashes soft in the opening cutscene (the fix is upstream
     now — no diagnostic lines to look for);
   - touch overlay present and working; real controller behaves as
     before (no change promised);
   - backgrounding still kills the Vulkan device (known iOS limit,
     unchanged by the upgrade).
6. **Movies.** On the Mac, run the v0.0.12 launcher's **Convert Movies**
   against the game folder (it manages its own Wine; multi-threaded).
   Copy the resulting per-scene MP4s into the phone's
   `FINAL FANTASY XIII/white_data/movie/`. Verify in game: a cutscene
   that used to skip (e.g. the z016 scenes) now plays with picture and
   sound, and later scenes in a multi-scene file play the *right* video.
7. **Keep / revert decision.** If anything above fails in a way we can't
   fix quickly, the v0.0.9 kit (step 1) rebuilds the IPA we already know
   runs. Nothing about the game data or saves changes either way.

## Risks, ranked

1. **Cocoa steering** — designed and compile-verified; the first-run
   log's window line is the proof it worked at runtime.
2. **New `__APPLE__` paths in `xrc_rt.c` / `xrc_thread.c`** (memory and
   threading setup took more macOS-specific routes in v0.0.12). Our
   stage markers localize any stall to a phase; this is the most likely
   source of a first-build debugging round.
3. **Link surprises** from new/changed files (`xrc_ir_glue.c`,
   `vk_sm3.c`). Mechanical fixes (skip list / defines), expected to be
   quick.
4. Longer full rebuild (bigger gen files). One-time cost per build
   thereafter incremental as usual.
